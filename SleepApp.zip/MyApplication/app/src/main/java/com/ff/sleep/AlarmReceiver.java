package com.ff.sleep;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Context oAppContext = context.getApplicationContext();

        if (oAppContext == null) {
            oAppContext = context;
        }

        if("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())){
            Intent serviceIntent = new Intent(oAppContext, sensorRecording.SensorService.class);
            oAppContext.startService(serviceIntent);
        }



    }
}
