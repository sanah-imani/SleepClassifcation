package com.ff.sleep;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class SensorService extends Service {
    public SensorService(){}

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        sensorRecording.plotDataS = true;
        audioRecording.plotDataA = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        sensorRecording.plotDataS = true;
        audioRecording.plotDataA = true;
        Log.w("sleepapp","sensor service");
        return Service.START_STICKY;
    }
}
