package com.ff.sleep;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class audioService extends Service {

    public audioService(){
        super();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        audioRecording.plotDataA = true;
        double amplitude = audioRecording.calcAmplitude();
        if(audioRecording.amplitudes.size() > 0){
            audioRecording.amplitudesV.add(amplitude/audioRecording.amplitudes.get(audioRecording.amplitudes.size()-1));
        }
        else{
            audioRecording.amplitudesV.add(1.00);
        }
        audioRecording.amplitudes.add(amplitude);
        if(audioRecording.plotDataA){
            audioRecording.addEntry(amplitude,audioRecording.c1);
            audioRecording.plotDataA = false;
        }
        Log.w("sleepapp","audio service");
        return Service.START_STICKY;
    }
}
