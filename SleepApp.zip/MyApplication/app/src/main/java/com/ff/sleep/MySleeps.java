package com.ff.sleep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;

import com.ff.sleep.R;

import java.util.ArrayList;
import java.util.List;

public class MySleeps extends AppCompatActivity {

    RecyclerView recyclerView;
    String[] TT, DT, ID;
    List<List<String>> mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sleeps);
        recyclerView = findViewById(R.id.recview1);

        getSleepsData(Profile.USER_EMAIL_PHONE);

        while(ID == null || (TT == null || DT == null)){
            //do nothing till data loads
        }

        mySleepsAdapter sleepsAdapter = new mySleepsAdapter(MySleeps.this, TT, DT, ID);
        recyclerView.setAdapter(sleepsAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MySleeps.this));
    }

    private void getSleepsData(String email_phone){
        mData = new ArrayList<>();
        List<String> user = new readCSV(MySleeps.this, "User").userProfiles();
        if(user.get(3) != "" && user.get(3) != null){
            ID = user.get(3).split("\\s+");
            TT = new String[ID.length];
            DT = new String[ID.length];
            for (int i = 0; i < ID.length; i++){
                SleepRecording mSR = new readCSV(MySleeps.this, "My Sleeps").readSingleRecord(ID[i]);
                TT[i] = mSR.getmSleepTimes();
                DT[i] = mSR.getmSleepDate();
            }
        }

    }
}
