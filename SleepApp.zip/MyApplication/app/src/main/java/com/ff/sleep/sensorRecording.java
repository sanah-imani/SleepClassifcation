package com.ff.sleep;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.List;

public class sensorRecording extends Activity implements SensorEventListener {
    private final String  TAG = "sensorRecording";

    private SensorManager sensorManager;
    Sensor lightSensor;
    Sensor motionDetect;
    Sensor gyroSense;
    Sensor accelerometer;
    Sensor step_counter;
    Sensor proximity;
    Context myCon;
    private boolean plotData = true;
    private Thread thread;

    LineChart c1, c2, c3, c4, c5;

    float light, motion, accelX, accelY, accelZ, gyroX, gyroY, gyroZ, step_count;
    List<Float> l1, m1, st1, l2, m2;
    List<List<Float>> g1, a1, g2,a2;

    private float[] gravity = new float[3];
    private List<Float> linear_acceleration = new ArrayList<>();

    public static int DELAY = 1000000;

    public sensorRecording(Context c1, Sensor light, Sensor motion, Sensor gyro, Sensor accel, Sensor step, Sensor prox, SensorManager manager){
        myCon = c1;
        sensorManager = manager;
        lightSensor = light;
        motionDetect = motion;
        gyroSense = gyro;
        accelerometer = accel;
        step_counter = step;
        proximity = prox;

        if (accelerometer != null){

            sensorManager.registerListener(this, accelerometer, DELAY);
        }
        if(lightSensor != null){
            sensorManager.registerListener(this, lightSensor, DELAY);
        }
        if(gyroSense != null){
            sensorManager.registerListener(this, gyroSense, DELAY);
        }
        if(motionDetect != null){
            sensorManager.registerListener(this, motionDetect, DELAY);
        }
        if(step_counter != null){
            sensorManager.registerListener(this, step_counter,DELAY);
        }

        if(proximity != null){
            sensorManager.registerListener(this,proximity,DELAY);
        }




        //initialising the arraylists
        l1 = new ArrayList<>();
        m1 = new ArrayList<>();
        g1 = new ArrayList<>();
        a1 = new ArrayList<>();
        st1 = new ArrayList<>();

        l2 = new ArrayList<>();
        m2 = new ArrayList<>();
        g2 = new ArrayList<>();
        a2 = new ArrayList<>();

        //x,y,z
        a1.add(0, new ArrayList<Float>());
        a1.add(1, new ArrayList<Float>());
        a1.add(2, new ArrayList<Float>());


        a2.add(0, new ArrayList<Float>());
        a2.add(1, new ArrayList<Float>());
        a2.add(2, new ArrayList<Float>());

        g1.add(0, new ArrayList<Float>());
        g1.add(1, new ArrayList<Float>());
        g1.add(2, new ArrayList<Float>());



        g2.add(0, new ArrayList<Float>());
        g2.add(1, new ArrayList<Float>());
        g2.add(2, new ArrayList<Float>());
    }


    @Override
    public void onSensorChanged(SensorEvent event) {

        if(event.sensor.getType() == Sensor.TYPE_LIGHT){
            light = event.values[0];

            if(l1.size() > 1){
                l1.add((new Float(light)/l2.get(l2.size()-1)));

            }
            else{
                l1.add(1f);
            }
            l2.add(new Float(light));

        }
        else if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            accelX = linAcc(event).get(0);
            accelY = linAcc(event).get(1);
            accelZ = linAcc(event).get(2);

            if(a1.get(0).size() >= 1){
                int indX = a2.get(0).size()-1;
                int indY = a2.get(1).size()-1;
                int indZ = a2.get(2).size()-1;
                a1.get(0).add(new Float(accelX/a2.get(0).get(indX)));
                a1.get(1).add(new Float(accelY/a2.get(1).get(indY)));
                a1.get(2).add(new Float(accelZ/a2.get(2).get(indZ)));

            }
            else{

                a1.get(0).add(1f);
                a1.get(1).add(1f);
                a1.get(2).add(1f);
            }
            a2.get(0).add(new Float(accelX));
            a2.get(1).add(new Float(accelY));
            a2.get(2).add(new Float(accelZ));

        }
        else if(event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            motion = event.values[0];
            if(m1.size() >= 1){
                m1.add((new Float(motion)/m2.get(m2.size()-1)));

            }
            else{
                m1.add(1f);
            }
            m2.add(new Float(motion));

        }
        else if(event.sensor.getType() == Sensor.TYPE_GYROSCOPE){
            gyroX = event.values[0];
            gyroY = event.values[1];
            gyroZ = event.values[2];



            if(g1.get(0).size() >= 1){
                int indX = g2.get(0).size()-1;
                int indY = g2.get(1).size()-1;
                int indZ = g2.get(2).size()-1;
                g1.get(0).add((new Float(gyroX)/g2.get(0).get(indX)));
                g1.get(1).add((new Float(gyroY)/g2.get(1).get(indY)));
                g1.get(2).add((new Float(gyroZ)/g2.get(2).get(indZ)));

            }
            else{
                g1.get(0).add(1f);
                g1.get(1).add(1f);
                g1.get(2).add(1f);
            }
            g2.get(0).add(new Float(gyroX));
            g2.get(1).add(new Float(gyroY));
            g2.get(2).add(new Float(gyroZ));

        }
        else if(event.sensor.getType() == Sensor.TYPE_STEP_COUNTER){
            step_count = event.values[0];
            st1.add(step_count);


        }
        else{

        }



        if(plotData){
            if(event.sensor.getType() == Sensor.TYPE_LIGHT) {

                addEntry(event, c1);

            }
            if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                addEntryComplex(event, c2, "Accel");

            }
            if(event.sensor.getType() == Sensor.TYPE_PROXIMITY){
                addEntry(event, c3);

            }
            if(event.sensor.getType() == Sensor.TYPE_GYROSCOPE){
                addEntryComplex(event, c4, "Gyr");

            }


            plotData = false;
        }


    }

    private void addEntryComplex(SensorEvent event, LineChart mChart, String type){



        LineData data = mChart.getData();
        if(data != null){
            ILineDataSet set = data.getDataSetByIndex(0);
            ILineDataSet set1 = data.getDataSetByIndex(1);
            ILineDataSet set2 = data.getDataSetByIndex(2);

            if(set == null){
                set = createSet(Color.MAGENTA);
                data.addDataSet(set);

            }
            if(set1 == null){
                set1 = createSet(Color.RED);
                data.addDataSet(set1);

            }
            if(set2 == null){
                set2 = createSet(Color.BLUE);
                data.addDataSet(set2);

            }
            if (type.equals("Accel")){
                data.addEntry(new Entry(set.getEntryCount(), linAcc(event).get(0)+5),0);
                data.addEntry(new Entry(set1.getEntryCount(), linAcc(event).get(1)+5),1);
                data.addEntry(new Entry(set2.getEntryCount(), linAcc(event).get(2)+5),2);
            }
            else{

                data.addEntry(new Entry(set.getEntryCount(), event.values[0]+5),0);
                data.addEntry(new Entry(set.getEntryCount(), event.values[1]+5),1);
                data.addEntry(new Entry(set.getEntryCount(), event.values[2]+5),2);


            }

            data.notifyDataChanged();
            mChart.notifyDataSetChanged();
            LegendEntry[] legendEntries = new LegendEntry[3];
            int[] colors = {Color.MAGENTA, Color.RED, Color.BLUE};
            String[] labels = {"X direction", "Y direction", "Z direction"};
            for (int i = 0; i < legendEntries.length; i++){
                LegendEntry entry = new LegendEntry();
                entry.formLineWidth = 5f;
                entry.formColor = colors[i];
                entry.label = labels[i];
                legendEntries[i] = entry;

            }
            mChart.getLegend().setCustom(legendEntries);
            mChart.getLegend().setOrientation(Legend.LegendOrientation.VERTICAL);
            mChart.getLegend().setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
            mChart.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
            mChart.setMaxVisibleValueCount(200);
            mChart.moveViewToX(data.getEntryCount());

        }

    }

    private void addEntry(SensorEvent event, LineChart mChart){

        LineData data = mChart.getData();
        if(data != null){
            ILineDataSet set = data.getDataSetByIndex(0);

            if(set == null){
                set = createSet(Color.MAGENTA);
                data.addDataSet(set);

            }

            data.addEntry(new Entry(set.getEntryCount(), event.values[0]+5),0);
            data.notifyDataChanged();
            mChart.getLegend().setEnabled(false);
            mChart.notifyDataSetChanged();
            mChart.setMaxVisibleValueCount(150);
            mChart.moveViewToX(data.getEntryCount());

        }

    }

    private LineDataSet createSet(int color){
        LineDataSet set = new LineDataSet(null, "Real-time Data");
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setLineWidth(3f);
        set.setCubicIntensity(0.2f);
        set.setDrawValues(false);
        set.setDrawCircles(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setColor(color);
        return set;
    }

    public void startPlot(LineChart chart1, LineChart chart2, LineChart chart3, LineChart chart4, LineChart chart5){
        if(thread != null){
            thread.interrupt();
        }
        if(chart1 != null){
            c1 = chart1;
        }
        if(chart2 != null){
            c2 = chart2;
        }
        if(chart3 != null){
            c3 = chart3;
        }
        if(chart4 != null){
            c4 = chart4;
        }
        if(chart5 != null){
            c5 = chart5;
        }
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    plotData = true;
                    try{
                        Thread.sleep(10);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void Pause(){
        if(thread != null){
            thread.interrupt();
        }
        thread.interrupt();
        sensorManager.unregisterListener((SensorEventListener) myCon);

    }

    public void Resume(){
        sensorManager.registerListener(this, lightSensor, DELAY);
        sensorManager.registerListener(this, accelerometer, DELAY);
        sensorManager.registerListener(this, gyroSense, DELAY);
        sensorManager.registerListener(this, motionDetect, DELAY);
        sensorManager.registerListener(this, step_counter, DELAY);
        sensorManager.registerListener(this,proximity,DELAY);

        startPlot(c1,c2,c3,c4,c5);

    }

    public List<Float> getL1() {
        return l1;
    }

    public List<Float> getM1() {
        return m1;
    }

    public List<Float> getSt1() {
        return st1;
    }

    public List<Float> getL2() {
        return l2;
    }

    public List<Float> getM2() {
        return m2;
    }

    public List<List<Float>> getG1() {
        return g1;
    }

    public List<List<Float>> getA1() {
        return a1;
    }

    public List<List<Float>> getG2() {
        return g2;
    }

    public List<List<Float>> getA2() {
        return a2;
    }

    public LineChart getC1(){
        return c1;
    }

    public LineChart getC2(){
        return c2;
    }
    public LineChart getC3(){
        return c3;
    }
    public LineChart getC4(){
        return c4;
    }
    public LineChart getC5(){
        return c5;
    }

    public void clear(){

            st1.clear();

            l2.clear();
            a2.clear();
            g2.clear();
            m2.clear();

    }

    public void clearV(){
        l1.clear();
        a1.clear();
        g1.clear();
        m1.clear();

    }

    private List<Float> linAcc(SensorEvent event){
        linear_acceleration.clear();
        final float alpha = 0.8f;

        gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

        linear_acceleration.add(0, event.values[0] - gravity[0]);
        linear_acceleration.add(1, event.values[1] - gravity[1]);
        linear_acceleration.add(2, event.values[2] - gravity[2]);

        return linear_acceleration;
    }

    public Thread getThread(){
        return thread;
    }

    public Context getContext(){
        return this;
    }

    public void restart(){

        //initialising the arraylists
        l2 = new ArrayList<>();
        m2 = new ArrayList<>();
        g2 = new ArrayList<>();
        a2 = new ArrayList<>();


        //x,y,z
        a2.add(0, new ArrayList<Float>());
        a2.add(1, new ArrayList<Float>());
        a2.add(2, new ArrayList<Float>());

        g2.add(0, new ArrayList<Float>());
        g2.add(1, new ArrayList<Float>());
        g2.add(2, new ArrayList<Float>());

    }

    public void restartV(){
        l1 = new ArrayList<>();
        m1 = new ArrayList<>();
        g1 = new ArrayList<>();
        a1 = new ArrayList<>();
        st1 = new ArrayList<>();


        a1.add(0, new ArrayList<Float>());
        a1.add(1, new ArrayList<Float>());
        a1.add(2, new ArrayList<Float>());

        g1.add(0, new ArrayList<Float>());
        g1.add(1, new ArrayList<Float>());
        g1.add(2, new ArrayList<Float>());

    }

}
