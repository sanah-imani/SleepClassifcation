package com.ff.sleep;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ff.sleep.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Results extends AppCompatActivity implements SensorEventListener, OnChartValueSelectedListener {

    TextView light, sound, motion, gyr, accel;
    String lightS, soundS, motionS, gyrS, accelS;
    String lightV, soundV, motionV, gyrV, accelV;

    public static float[] thresholds = {0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f};
    public static float[] thresholdsV = {0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f};

    private String date;

    BarChart barChart;
    RecyclerView recyclerView;
    String[] type_sense = {"Average Accelerometer Data during sleep", "Average Proximity Detection Data during sleep", "Average Gyroscope Data during sleep", "Average Light Level Data during sleep", "Average Sound Level Data during sleep"};
    List<String> to_display = new ArrayList<>();
    private SleepRecording sr;
    List<String> timePoints;
    String SleepID;
    String[] labels;
    float[] yValues;

    TextView sleep_dur;
    ProgressBar progressBar;
    graphsAdapter gA = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        sleep_dur = findViewById(R.id.durSleep);
        progressBar = findViewById(R.id.progress_horizontal);
        //get Important Data
        getData();
        while(SleepID == null){
            progressBar.setVisibility(View.VISIBLE);
            //do nothing
        }
        try {
            sr = new readCSV(Results.this, "My Sleeps").readSingleRecord(SleepID);
            ;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        long startTime = System.currentTimeMillis();

        while (sr == null && System.currentTimeMillis()-startTime < 5000){

            //waiting 5000 millis to fetch the data
        }

        progressBar.setVisibility(View.GONE);

        if(sr != null){
            sleep_dur.setText("You have slept from " + sr.getmSleepTimes());

            lightS = sr.getmLightaverage();
            accelS = sr.getmAccAverage();
            gyrS = sr.getmGyroAverage();
            motionS = sr.getmMotionAverage();
            soundS = sr.getmSoundAverage();
            lightV = sr.getmLightAV();
            soundV = sr.getmSoundAV();
            motionV = sr.getmMotionAV();
            gyrV = sr.getmGryoAV();
            accelV = sr.getmAccAV();

            light = findViewById(R.id.light);
            light.setText("Light Score: " + lightS + " (" + lightV + ")");
            sound = findViewById(R.id.sound);
            sound.setText("Sound Score: " + soundS + " (" + soundV + ")");
            motion = findViewById(R.id.motion);
            motion.setText("Motion Score: " + " (" + motionV + ")");
            gyr = findViewById(R.id.gyr);
            gyr.setText("Gyroscope Score: "+ gyrS + " (" + gyrV + ")");
            accel = findViewById(R.id.accel);
            accel.setText("Accelerometer Score: "+ accelS + " (" + accelV + ")");

            barChart = findViewById(R.id.bar_usage_stats);
            recyclerView = findViewById(R.id.recview2);

            //default show accelerometer avg
            to_display.add("Average Accelerometer Data during sleep");

            timePoints = new ArrayList<>();
            for (int i = 0; i < ((int) (Float.parseFloat(sr.getmSleepDuration())/30)) + 1; i++){
                timePoints.add(String.valueOf(i));
            }

            //recyclerView adapter
            gA = new graphsAdapter(Results.this, to_display, sr, timePoints);
            recyclerView.setAdapter(gA);
            recyclerView.setLayoutManager(new LinearLayoutManager(Results.this));

            ChipGroup chipGroup = findViewById(R.id.chip_group1);
            for (int i = 0; i < type_sense.length; i++) {

                View view = LayoutInflater.from(this).inflate(R.layout.chip_row, chipGroup, false);
                final Chip chip = view.findViewById(R.id.loc_chip);
                chip.setText(type_sense[i]);
                chip.setClickable(true);
                chip.setCheckable(true);
                chipGroup.addView(chip);
                if(chip.getText().toString().equals("Average Accelerometer Data during sleep")){
                    chip.setChecked(true);
                }
                chip.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(chip.isChecked()){
                            to_display.add(chip.getText().toString());
                            gA.updateList(to_display);


                        }
                        else{

                            to_display.remove(chip.getText().toString());
                            gA.updateList(to_display);

                        }

                    }
                });
            }

            List<String> xValues = sr.getMpackageName();
            List<String> yVals = sr.getMuseTime();
            if(xValues != null && yVals != null){
                labels = new String[xValues.size()];
                yValues = new float[yVals.size()];
                for(int i = 0; i <xValues.size(); i++){
                    labels[i] = xValues.get(i);
                    yValues[i] = Float.parseFloat(yVals.get(i));


                }

                barChart = new myTrends(Results.this).setBarChart(labels,yValues,"App Usage During Sleep",barChart, "App Names");
            }

        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Sorry no data could be recovered")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            startActivity(new Intent(Results.this,MainActivity.class));
                        }
                    });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }




    }

    @Override
    public void onSensorChanged(SensorEvent event) {

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void getData(){
        Bundle bundle = getIntent().getExtras();


        if (bundle != null){
            SleepID = bundle.getString("Sleep ID");
        }

    }

    public void retHome(View view) {
        Intent intent = new Intent(Results.this,MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {



    }

    @Override
    public void onNothingSelected() {

    }
}
