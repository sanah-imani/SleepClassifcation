package com.ff.sleep;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.ff.sleep.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    Button b1,b2;
    BottomNavigationView bottomNav;
    List<String[]> allLinesUser;
    List<String[]> allLinesProfile;
    List<String[]> allLinesSR;

    public static boolean IS_STORAGE_WRITEABLE = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getIntent().hasExtra("Restart")){
            startActivity(new Intent(MainActivity.this, inBackground.class));
        }
        bottomNav = findViewById(R.id.bottom_navigation);

        bottomNav.setOnNavigationItemSelectedListener(navListener);
        bottomNav.setSelectedItemId(R.id.aboutUs);

        setStorageDirs();

    }
    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            Fragment selectedFrag = null;
            switch (menuItem.getItemId()){
                case R.id.aboutUs:
                    selectedFrag = new AboutSleepFragment();
                    break;
                case R.id.profile:
                    selectedFrag = new ProfileFragment();
                    break;
                case R.id.sleep:
                    selectedFrag = new SleepsFragment();
                    break;
                case R.id.settings:
                    selectedFrag = new SettingsFragment();
                    break;
                default:
                    selectedFrag = new SleepsFragment();
                    menuItem.setChecked(true);
                    break;


            }

            if(getSupportFragmentManager().findFragmentById(R.id.frame_container) != null){
                if(getSupportFragmentManager().findFragmentById(R.id.frame_container).isAdded() && getSupportFragmentManager().findFragmentById(R.id.frame_container).equals(selectedFrag)){

                }
                else{
                    getSupportFragmentManager().beginTransaction().replace(R.id.frame_container,selectedFrag).commit();
                }

            }
            else{
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container,selectedFrag).commit();
            }

            return true;
        }
    };

    public void setStorageDirs(){

        if(isExternalStorageWritable()){

            IS_STORAGE_WRITEABLE = true;
            File file = new File(MainActivity.this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SleepApp");
            if (!file.exists()) {
                file.mkdir();
                Log.d(TAG, "Setting up!");
            }
            try {
                File gpxfile = new File(file, "Profile.csv");

                Log.d(TAG, "Setting up!");
                if (!gpxfile.exists()){
                    allLinesProfile = new ArrayList<>();

                    allLinesProfile.add(0, new String[]{"Username","Email_Phone","Profile_pic","Age","Device","System","Weight","Height","Desired_Sleep","Notifications"});
                    allLinesProfile.add(1,new String[]{"Zahrah_Imani","sanah@fourthfrontier.com","None","20","12567Z","Metric","60","170","9","False"});

                    CSVWriter writer = new CSVWriter(new FileWriter(gpxfile));
                    writer.writeAll(allLinesProfile);
                    writer.flush();
                    writer.close();
                }




            } catch (Exception e) { }


            File file2 = new File(MainActivity.this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SleepApp");
            if (!file2.exists()) {
                file2.mkdir();
            }
            try {
                File gpxfile = new File(file, "User.csv");

                if(!gpxfile.exists()){
                    allLinesUser = new ArrayList<>();
                    allLinesUser.add(0, new String[]{"Username", "Password", "Email/Phone", "Sleeps"});
                    allLinesUser.add(1, new String[]{"Zahrah_Imani","fountier123","sanah@fourthfrontier.com", ""});
                    CSVWriter writer = new CSVWriter(new FileWriter(gpxfile));
                    writer.writeAll(allLinesUser);
                    Log.d(TAG, writer.toString());
                    writer.close();
                }




            } catch (Exception e) { }

            File file3 = new File(MainActivity.this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SleepApp");
            if (!file3.exists()) {
                file3.mkdir();
            }
            try {
                File gpxfile = new File(file, "Sleep_Recordings.csv");
                if(!gpxfile.exists()){
                    allLinesSR = new ArrayList<>();
                    String labels = "Sleep_id,Sleep date,Sleep times,Sleep Score,Sleep Duration,Average Motion,Average Accelerometer,Average Light,Average Sound,Average Gyro,Average MotionV,Average AccelerometerV,Average LightV,Average SoundV,Average GyroV,MotionA,AccelerometerA,LightA,SoundA,GyroA,MotionA,AccelerometerV,LightV,SoundV,GyroV,Package Name,Time Used";
                    String[] tokens = labels.split(",");
                    allLinesSR.add(0, tokens);
                    CSVWriter writer = new CSVWriter(new FileWriter(gpxfile));
                    writer.writeAll(allLinesSR);
                    writer.flush();
                    writer.close();

                }

            } catch (Exception e) { }
        }
        else{
            Toast.makeText(MainActivity.this,"No external storage available",Toast.LENGTH_LONG).show();
        }

    }

    private boolean isExternalStorageWritable(){
        if(Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())){
            Log.i("State", "Yes it is writable");
            return true;
        }
        else {
            return false;
        }
    }
}
