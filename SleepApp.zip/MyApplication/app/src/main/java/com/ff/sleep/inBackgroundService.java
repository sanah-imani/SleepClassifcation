package com.ff.sleep;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class inBackgroundService extends Service {

    public inBackgroundService(){
        super();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        inBackground.createAveragesV(inBackground.sr.getL1(),inBackground.sr.getM1(),inBackground.sr.getG1(),inBackground.sr.getA1(), inBackground.ar.getAmplitudesV());
        inBackground.createAverages(inBackground.sr.getL2(),inBackground.sr.getM2(),inBackground.sr.getG2(),inBackground.sr.getA2(), inBackground.sr.getSt1(),inBackground.ar.getAmplitudes());
        Log.w("sleepapp","background service");
        return Service.START_STICKY;
    }


}

