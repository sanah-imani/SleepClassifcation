package com.ff.sleep;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.anychart.AnyChartView;
import com.anychart.charts.Pie;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.github.mikephil.charting.charts.BarChart;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

public class ProfileFragment extends Fragment {

    String[] sleep_qual = {"Poor", "Average", "Good", "Excellent"};
    String[] sleep_time_pie = {"Met sleep time goal", "Less than sleep goal time"};
    double[] perc_qual;
    double[] perc_time;
    private List<String> profile_tokens;
    public static String USER_NAME;
    public static String USER_EMAIL_PHONE;
    public static String SLEEP_TARGET;


    List<List<String>> mData;

    AnyChartView chart1, chart2;
    BarChart barChart1, barChart2, barChart3, barChart4;
    float[] sleep_time_bar, light_bar, motion_bar, sound_bar;
    CheckBox check1;
    Button edit, sync;
    Boolean editing = false;
    TextInputEditText age, sleep_time, weight, height;
    TextView device_name;
    ImageView profile_pic;
    RadioButton rb1, rb2;
    CheckBox vib;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_profile, container, false);

        chart1 = view.findViewById(R.id.sleep_qual);
        chart2 = view.findViewById(R.id.sleep_time_pie);
        barChart1 = view.findViewById(R.id.sleep_time_bar);
        barChart2 = view.findViewById(R.id.light_var_bar);
        barChart3 = view.findViewById(R.id.motion_var_bar);
        barChart4 = view.findViewById(R.id.sound_var_bar);
        check1 = view.findViewById(R.id.check1);
        edit = view.findViewById(R.id.editprofile);
        age = view.findViewById(R.id.age);
        sleep_time = view.findViewById(R.id.sleep_time);
        weight = view.findViewById(R.id.weight);
        height = view.findViewById(R.id.height);
        profile_pic = view.findViewById(R.id.profile);
        rb1 = view.findViewById(R.id.metric);
        rb2 = view.findViewById(R.id.imperial);
        device_name = view.findViewById(R.id.sync);
        vib = view.findViewById(R.id.check1);
        getData();
        getUser();
        fillProfile();
        profile_pic.setEnabled(false);
        rb1.setEnabled(false);
        rb2.setEnabled(false);
        age.setEnabled(false);
        sleep_time.setEnabled(false);
        weight.setEnabled(false);
        height.setEnabled(false);
        vib.setEnabled(false);

        if(mData == null){
            //do nothing until we get the data
        }

        getSleepScorePerc(3);
        getSleepTimeFulfilled(4);

        Pie pie1 = new myTrends(getActivity()).setUpPie(sleep_qual, perc_qual);
        chart1.setChart(pie1);
        pie1.legend()
                .position("center-bottom")
                .itemsLayout(LegendLayout.HORIZONTAL)
                .align(Align.CENTER);

        if (pie1 == null){
            Toast.makeText(getActivity(), "No sleep quality pie chart could be generated", Toast.LENGTH_SHORT).show();
        }


        Pie pie2 = new myTrends(getActivity()).setUpPie(sleep_time_pie, perc_time);
        chart1.setChart(pie2);
        pie2.legend()
                .position("center-bottom")
                .itemsLayout(LegendLayout.HORIZONTAL)
                .align(Align.CENTER);

        if (pie2 == null){
            Toast.makeText(getActivity(), "No sleep time goal chart could be generated", Toast.LENGTH_SHORT).show();
        }

        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        barChart1 = new myTrends(getActivity()).setBarChart(days,sleep_time_bar, "Sleep time during this week", barChart1, "Week days");
        barChart2 = new myTrends(getActivity()).setBarChart(days,light_bar, "Sleep light variation during this week", barChart2, "Week days");
        barChart3 = new myTrends(getActivity()).setBarChart(days,motion_bar, "Sleep motion variation during this week", barChart3, "Week days");
        barChart4 = new myTrends(getActivity()).setBarChart(days, sound_bar, "Sleep sound variation during this week", barChart4, "Week days");

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editing){
                    Boolean val = checkValidation();
                    if (val){
                        Toast.makeText(getActivity(), "Saved Successfully", Toast.LENGTH_LONG).show();
                        edit.setText("Edit");
                        editing = false;
                        profile_pic.setEnabled(false);
                        rb1.setEnabled(false);
                        rb2.setEnabled(false);
                        age.setEnabled(false);
                        sleep_time.setEnabled(false);
                        weight.setEnabled(false);
                        height.setEnabled(false);
                        vib.setEnabled(false);
                    }
                    else{
                        Toast.makeText(getActivity(), "Did not save", Toast.LENGTH_LONG).show();

                    }

                }
                else{
                    edit.setText("Save");
                    profile_pic.setEnabled(true);
                    rb1.setEnabled(true);
                    rb2.setEnabled(true);
                    editing = true;
                    age.setEnabled(true);
                    sleep_time.setEnabled(true);
                    weight.setEnabled(true);
                    height.setEnabled(true);
                    vib.setEnabled(true);

                }

            }
        });

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rb2.isChecked() && rb1.isChecked()){
                    rb2.setChecked(false);
                }

            }
        });

        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rb1.isChecked() && rb2.isChecked()){
                    rb1.setChecked(false);
                }

            }
        });

        return view;
    }


    public boolean checkValidation(){
        if(!TextUtils.isDigitsOnly(age.getText()) || !TextUtils.isDigitsOnly(sleep_time.getText()) || !TextUtils.isDigitsOnly(height.getText()) || !TextUtils.isDigitsOnly(weight.getText())){
            Toast.makeText(getActivity(), "Numeric values to be entered", Toast.LENGTH_LONG).show();
            return false;
        }
        else if(Integer.parseInt(age.getText().toString()) <= 0 || Integer.parseInt(sleep_time.getText().toString()) <= 0 || Integer.parseInt(height.getText().toString()) <= 0 || Integer.parseInt(weight.getText().toString()) <= 0){
            Toast.makeText(getActivity(), "Negative values are not accepted", Toast.LENGTH_LONG).show();
            return false;
        }
        else if(!rb1.isChecked() && !rb2.isChecked()){
            Toast.makeText(getActivity(), "You need to select a measuring scale", Toast.LENGTH_LONG).show();
            return false;

        }
        else{

        }

        return true;
    }

    public void getUser(){

        List<String> userTokens = new readCSV(getActivity(), "User").userProfiles();
        if (userTokens != null){
            USER_NAME = userTokens.get(0);
            USER_EMAIL_PHONE = userTokens.get(1);
        }
    }

    public void fillProfile(){
        profile_tokens = new readCSV(getActivity(), "Profile").readProfiles(USER_NAME, USER_EMAIL_PHONE);
        age.setText(profile_tokens.get(3));
        device_name.setText("Frontier X " + profile_tokens.get(4));
        sleep_time.setText(profile_tokens.get(4));
        if(profile_tokens.get(5).equalsIgnoreCase("Imperial")){
            rb2.setChecked(true);

        }
        else if(profile_tokens.get(5).equalsIgnoreCase("Metric")){
            rb1.setChecked(true);
        }
        SLEEP_TARGET = profile_tokens.get(6);
        weight.setText(profile_tokens.get(7));
        height.setText(profile_tokens.get(8));
    }


    public void getData(){
        mData = new readCSV(getActivity(), "My Sleeps").readRecord();
    }

    public void getSleepTimeFulfilled(int timeIndex){
        perc_time = new double[sleep_time_pie.length];
        perc_time[0] = 0;
        int count = mData.size();
        for (List<String> l1: mData){
            if(Integer.parseInt(SLEEP_TARGET) >= Integer.parseInt(l1.get(timeIndex))){
                perc_time[0] += 1;

            }
        }

        if (count > 0){
            perc_time[0] = (perc_time[0]/count)*100;
            perc_time[1] = 100.00-perc_time[0];

        }
    }

    public void getSleepScorePerc(int scoreIndex){
        perc_qual = new double[sleep_qual.length];
        if(mData.size() > 0){
            for (int i = 0; i < perc_qual.length;i++){
                perc_qual[i] = 0;
            }
            int count = mData.size();
            for (List<String> l1: mData){
                if(Integer.parseInt(l1.get(scoreIndex)) >= 8){
                    perc_qual[0] += 1;

                }
                else if(Integer.parseInt(l1.get(scoreIndex)) >= 6){
                    perc_qual[1] += 1;
                }
                else if(Integer.parseInt(l1.get(scoreIndex)) >= 4){
                    perc_qual[2] += 1;
                }
                else{
                    perc_qual[3] += 1;
                }
            }
            for(int j = 0; j <perc_qual.length;j++){
                perc_qual[j] = (perc_qual[j]/count)*100;

            }



        }

    }
}
