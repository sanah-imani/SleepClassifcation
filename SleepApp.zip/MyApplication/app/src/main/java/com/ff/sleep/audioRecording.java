package com.ff.sleep;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.SensorEvent;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class audioRecording extends Activity {
    final int REQUEST_PERMISSION_CODE = 1000;

    MediaRecorder mRecorder;
    Boolean running1 = true;
    Context myCon;
    List<Double> amplitudes;
    List<Double> amplitudesV;

    //plotting
    LineChart c1;
    private boolean plotData = true;
    Thread thread;

    private final int AUDIO_RECORDING_DELAY = 1000;
    private final double referenceAmplitude = 0.0001;
    private Handler mHandler;
    PowerManager.WakeLock mWakeLock;
    AlarmManager am;
    PendingIntent pendingIntent;

    public audioRecording(Context c1) throws IOException {
        myCon = c1;
        amplitudesV = new ArrayList<>();
        amplitudes = new ArrayList<>();
        amplitudesV.add(1.00);
        mHandler = new Handler();
    }

    public void acquireWakeLock() {
        final PowerManager powerManager = (PowerManager) myCon.getSystemService(Context.POWER_SERVICE);
        releaseWakeLock();
        //Acquire new wake lock
        mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PARTIAL_WAKE_LOCK:");
        mWakeLock.acquire();
    }

    public void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            mWakeLock = null;
        }
    }

    public void start(){
        if(checkPermissionFromDevice()){

            record();
        }
        else{

            requestPermission();
        }

    }

    public void record(){

        setUpMediaRecorder();
        try{
            mRecorder.prepare();
            mRecorder.start();
        }catch (IllegalStateException e) {
            e.printStackTrace();}
        catch (IOException e){
            e.printStackTrace();
        }

    }

    private void setUpMediaRecorder(){
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mRecorder.setAudioSamplingRate(1000);
        mRecorder.setOutputFile("/dev/null");
    }

    private void requestPermission(){
        ActivityCompat.requestPermissions((Activity) myCon, new String[]{
                Manifest.permission.RECORD_AUDIO
        }, REQUEST_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_PERMISSION_CODE:{
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(myCon, "Microphone permission granted", Toast.LENGTH_LONG).show();
                    record();


                }
                else{
                    Toast.makeText(myCon, "Microphone permission denied", Toast.LENGTH_LONG).show();
                }
                break;
            }
        }
    }


    private boolean checkPermissionFromDevice(){
        int record_audio_result = ContextCompat.checkSelfPermission(myCon,Manifest.permission.RECORD_AUDIO);
        return record_audio_result == PackageManager.PERMISSION_GRANTED;
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public void pauseMicrophone(){
        if(mRecorder != null){
            mRecorder.pause();
            running1 = false;
        }
        releaseWakeLock();
        if(am != null && pendingIntent != null){
            am.cancel(pendingIntent);
        }
    }

    public void resumeMicrophone(){
        if(mRecorder != null){
            mRecorder.resume();
            running1 = true;
        }
        startPlot(c1);
        acquireWakeLock();
    }

    public void stopMicrophone(){
        if (mRecorder != null) {
            mRecorder.stop();
            mRecorder.reset();
            mRecorder.release();
            mRecorder = null;
        }

        if(am != null && pendingIntent != null){
            am.cancel(pendingIntent);
        }

    }

    public double calcAmplitude() {
        if(mRecorder != null){
            final double maxAmplitude = mRecorder.getMaxAmplitude();
            return maxAmplitude;
        }
        else{
            return 0.0;
        }

    }


    public List<Double> getAmplitudes(){
        return amplitudes;
    }

    public List<Double> getAmplitudesV(){
        return amplitudesV;
    }

    public void startPlot(LineChart chart1){
        c1 = chart1;
        acquireWakeLock();
        am = (AlarmManager)myCon.getSystemService(ALARM_SERVICE);
        Intent i = new Intent(myCon, AlarmReceiveAudio.class);
        pendingIntent = PendingIntent.getBroadcast(
                myCon, 0, i, PendingIntent.FLAG_UPDATE_CURRENT);

        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(System.currentTimeMillis());

        int interval = 1000;
        am.setRepeating(AlarmManager.RTC, t.getTimeInMillis(), interval, pendingIntent);

    }

    private void addEntry(Double value,LineChart mChart){
        LineData data = mChart.getData();
        if(data != null){
            ILineDataSet set = data.getDataSetByIndex(0);

            if(set == null){
                set = createSet();
                data.addDataSet(set);

            }

            data.addEntry(new Entry(set.getEntryCount(), Float.parseFloat(String.valueOf(value))),0);
            data.notifyDataChanged();
            mChart.notifyDataSetChanged();
            mChart.setMaxVisibleValueCount(200);
            mChart.moveViewToX(data.getEntryCount());

        }

    }

    private LineDataSet createSet(){
        LineDataSet set = new LineDataSet(null, "Real-time Data");
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setDrawCircles(false);
        set.setDrawValues(false);
        set.setLineWidth(3f);
        set.setCubicIntensity(0.2f);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setColor(Color.MAGENTA);
        return set;
    }

    public LineChart getC1() {
        return c1;
    }

    public Thread getThread(){
        return thread;
    }

    public void clear(){

        amplitudes.clear();


    }

    public void clearV(){
        amplitudesV.clear();
    }

    public void restart(){
        amplitudes = new ArrayList<>();
    }

    public void restartV(){
        amplitudesV = new ArrayList<>();
    }


    public static class AlarmReceiveAudio extends BroadcastReceiver {


        @Override
        public void onReceive(Context context, Intent intent) {

            Context oAppContext = context.getApplicationContext();

            if (oAppContext == null) {
                oAppContext = context;
            }

            if("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())){
                Intent serviceIntent2 = new Intent(oAppContext, audioService.class);
                oAppContext.startService(serviceIntent2);
            }


        }

    }

    public class audioService extends Service{

        public audioService(){
            super();
        }

        @Nullable
        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override
        public void onCreate() {

        }

        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            plotData = true;
            double amplitude = calcAmplitude();
            if(amplitudesV.size() > 0){
                amplitudesV.add(amplitude/amplitudes.get(amplitudes.size()-1));
            }
            else{
                amplitudesV.add(1.00);
            }
            amplitudes.add(amplitude);
            if(plotData){
                addEntry(amplitude,c1);
                plotData = false;
            }

            return Service.START_STICKY;
        }
    }

}
