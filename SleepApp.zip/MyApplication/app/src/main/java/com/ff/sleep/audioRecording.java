package com.ff.sleep;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.SensorEvent;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.io.IOException;
import java.util.List;

public class audioRecording extends AppCompatActivity {
    final int REQUEST_PERMISSION_CODE = 1000;

    MediaRecorder mRecorder;
    Boolean running1;
    Context myCon;
    List<Double> amplitudes;
    List<Double> amplitudesV;

    //plotting
    LineChart c1;
    private boolean plotData = true;
    private Thread thread;

    private final int AUDIO_RECORDING_DELAY = 1000;
    private final double referenceAmplitude = 0.0001;



    public audioRecording(Context c1) throws IOException {
        myCon = c1;
        amplitudesV.add(1.00);
    }

    public void start(){
        if(checkPermissionFromDevice()){

            record();
        }
        else{

            requestPermission();
        }

    }

    public void record(){

        setUpMediaRecorder();
        try{
            mRecorder.prepare();
            mRecorder.start();
        }catch (IllegalStateException e) {
            e.printStackTrace();}
        catch (IOException e){
            e.printStackTrace();
        }

    }

    private void setUpMediaRecorder(){
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mRecorder.setOutputFile("/dev/null");
    }

    private void requestPermission(){
        ActivityCompat.requestPermissions((Activity) myCon, new String[]{
                Manifest.permission.RECORD_AUDIO
        }, REQUEST_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_PERMISSION_CODE:{
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(myCon, "Microphone permission granted", Toast.LENGTH_LONG).show();
                    record();

                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            final double amplitude = calcAmplitude();
                            amplitudes.add(amplitude);
                            if(amplitudes.size() > 0){
                                amplitudesV.add(amplitude/amplitudes.get(amplitudes.size()-1));
                            }

                            addEntry(amplitude,c1);
                            handler.postDelayed(this, AUDIO_RECORDING_DELAY);
                        }
                    }, AUDIO_RECORDING_DELAY);
                }
                else{
                    Toast.makeText(myCon, "Microphone permission denied", Toast.LENGTH_LONG).show();
                }
                break;
            }
        }
    }


    private boolean checkPermissionFromDevice(){
        int record_audio_result = ContextCompat.checkSelfPermission(myCon,Manifest.permission.RECORD_AUDIO);
        return record_audio_result == PackageManager.PERMISSION_GRANTED;
    }



    @RequiresApi(api = Build.VERSION_CODES.N)
    public void pauseMicrophone(){
        if(mRecorder != null){
            mRecorder.pause();
        }
    }

    public void stopMicrophone(){
        if (mRecorder != null) {
            mRecorder.stop();
            mRecorder.release();
            mRecorder = null;
        }

    }

    public double calcAmplitude() {
        if(mRecorder != null){
            final double maxAmplitude = mRecorder.getMaxAmplitude();
            final double amplitude = 20 * Math.log10(maxAmplitude / referenceAmplitude);

            return amplitude;
        }
        else{
            return 0.0;
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        start();
    }

    public List<Double> getAmplitudes(){
        return amplitudes;
    }

    public List<Double> getAmplitudesV(){
        return amplitudesV;
    }

    public void startPlot(LineChart chart1){
        if(thread != null){
            thread.interrupt();
        }
        c1 = chart1;
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    plotData = true;
                    try{
                        Thread.sleep(10);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        });

    }

    private void addEntry(Double value,LineChart mChart){
        LineData data = mChart.getData();
        if(data != null){
            ILineDataSet set = data.getDataSetByIndex(0);

            if(set == null){
                set = createSet();
                data.addDataSet(set);

            }

            data.addEntry(new Entry(set.getEntryCount(), Float.parseFloat(String.valueOf(value))),0);
            data.notifyDataChanged();
            mChart.setMaxVisibleValueCount(200);
            mChart.moveViewToX(data.getEntryCount());

        }

    }

    private LineDataSet createSet(){
        LineDataSet set = new LineDataSet(null, "Real-time Data");
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setLineWidth(3f);
        set.setCubicIntensity(0.2f);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setColor(Color.MAGENTA);
        return set;
    }

    public LineChart getC1() {
        return c1;
    }
}
