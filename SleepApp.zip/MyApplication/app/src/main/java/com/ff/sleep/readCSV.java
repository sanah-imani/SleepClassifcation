package com.ff.sleep;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class readCSV {

    private String myPath;
    private List<String> tokens;
    List<List<String>> mdata;
    private Context myCon;

    private InputStream is = null;

    public readCSV(Context c1, String label) throws FileNotFoundException {
        myPath = label;
        myCon = c1;

        if(myPath.equals("My Sleeps")){
            File initFile = new File(myCon.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SleepApp");
            if(initFile.exists()){
                File targetFile = new File(initFile, "Sleep_Recordings.csv");
                if(targetFile.exists()){
                    is = new FileInputStream(targetFile);

                }
            }

        }
        if(myPath.equals("Profile")){
            File initFile = new File(myCon.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SleepApp");
            if(initFile.exists()){
                File targetFile = new File(initFile, "Profile.csv");
                if(targetFile.exists()){
                    is = new FileInputStream(targetFile);
                }
            }
        }
        if(myPath.equals("User")){

            File initFile = new File(myCon.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SleepApp");
            if(initFile.exists()){
                File targetFile = new File(initFile, "User.csv");
                if(targetFile.exists()){
                    is = new FileInputStream(targetFile);
                }



            }
        }
    }

    public List<List<String>> readRecord(){

        mdata = new ArrayList<>();


        if (is != null){
            final BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String line = "";

            try {
                int count = 0;
                while ((line = br.readLine()) != null) {
                    if (count > 0){

                        String[] tokens = line.split((",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"));
                        for (int i = 0; i < tokens.length; i++) {
                            tokens[i] = tokens[i].replaceAll("\"", "");
                        }

                        List<String> singRec = new ArrayList<>();

                        for (int i = 0; i < (tokens.length); i++){
                            singRec.add(i,tokens[i]);

                        }
                        mdata.add(singRec);

                    }

                    count++;

                }
            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }

        }

        return mdata;
    }


    public List<List<String>> readQueryRecord(String[] IDs){

        mdata = new ArrayList<>();

        if (is != null){
            final BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String line = "";

            try {
                int count = 0;
                while ((line = br.readLine()) != null) {

                    if (count > 0){


                        String[] tokens = line.split((",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"));
                        for (int i = 0; i < tokens.length; i++) {
                            tokens[i] = tokens[i].replaceAll("\"", "");
                        }
                        if(Arrays.asList(IDs).contains(tokens[0])){
                            List<String> singRec = new ArrayList<>();

                            for (int i = 0; i < (tokens.length); i++){
                                singRec.add(i,tokens[i]);

                            }
                            mdata.add(singRec);

                        }

                    }

                    count++;

                }
            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }

        }

        return mdata;
    }

    public List<String> readProfiles(String username, String email_phone){


        if (is != null){
            final BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String line = "";
            tokens = new ArrayList<>();

            try {
                int count = 0;
                while ((line = br.readLine()) != null) {
                    if(count>0){

                        String[] alltokens = line.split((",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"));
                        for (int i = 0; i < alltokens.length; i++) {
                            alltokens[i] = alltokens[i].replaceAll("\"", "");
                        }
                        if(alltokens[0].equals(username) && alltokens[1].equals(email_phone)){
                            for (int i = 0; i < (alltokens.length); i++){
                                tokens.add(i,alltokens[i]);
                            }

                        }

                    }
                    count++;


                }
            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }

        }
        return tokens;
    }

    public List<String> userProfiles(){
        if(tokens != null){
            tokens.clear();
        }

        if (is != null){
            final BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String line = "";
            tokens = new ArrayList<>();

            try {
                int count = 0;
                while ((line = br.readLine()) != null) {
                    Log.d("readCSV", line);
                    if (count > 0){
                        Log.d("readCSV", line);
                        String[] alltokens = line.split((",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"));
                        for (int i = 0; i < alltokens.length; i++) {
                            alltokens[i] = alltokens[i].replaceAll("\"", "");
                        }
                        for (String token: alltokens){

                            tokens.add(token);

                        }
                    }
                    count++;
                }
            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }

        }
        return tokens;

    }


    public SleepRecording readSingleRecord(String SleepID){

        SleepRecording sr = null;

        if (is != null){
            final BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String line = "";

            String[] tokenArr = null;

            Log.d("readCSV", "Fetching data");

            try {
                int count  = 0;
                while ((line = br.readLine()) != null) {
                    Log.d("readCSV",line);

                    List<List<Float>> recSensor = new ArrayList();
                    List<List<Double>> recSound = new ArrayList();
                    List<String> packNames = new ArrayList<>();
                    List<String> timeUse = new ArrayList<>();
                    if (count > 0){

                        tokenArr = line.split((",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"));
                        for (int i = 0; i < tokenArr.length; i++) {
                            tokenArr[i] = tokenArr[i].replaceAll("\"", "");
                        }

                        if(tokenArr[0].equals(SleepID)){


                            for (int i = 15; i < tokenArr.length; i++) {

                                if (i == 19 || i == 24) {
                                    if(tokenArr[i].length() > 0){
                                        List<Double> sound = new ArrayList<>();
                                        String[] sub = tokenArr[i].split("\\s+");
                                        for (String s : sub) {
                                            sound.add(Double.parseDouble(s));
                                        }
                                        recSound.add(sound);
                                    }


                                }

                                else if(i == 25){
                                    String[] sub = tokenArr[i].split("\\s+");
                                    for (String s : sub) {
                                        packNames.add(s);
                                    }
                                }

                                else if(i == 26){
                                    String[] sub = tokenArr[i].split("\\s+");
                                    for (String s : sub) {
                                        timeUse.add(s);
                                    }
                                }

                                else {

                                    List<Float> sensors = new ArrayList<>();
                                    String[] sub = tokenArr[i].split("\\s+");
                                    for (String s : sub) {
                                        sensors.add(Float.parseFloat(s));
                                    }
                                    recSensor.add(sensors);
                                }



                            }



                            if(packNames == null || packNames.size() == 0){
                                packNames = null;
                            }
                            if(timeUse == null || timeUse.size() == 0){
                                timeUse = null;
                            }

                            List<Double> addRandomSound = new ArrayList<>();
                            addRandomSound.add(Double.NaN);
                            recSound.add(addRandomSound);



                            sr = new SleepRecording(tokenArr[0],tokenArr[1],tokenArr[2],tokenArr[3], tokenArr[4], tokenArr[5], tokenArr[6], tokenArr[7], tokenArr[8], tokenArr[9], tokenArr[10], tokenArr[11], tokenArr[12], tokenArr[13], tokenArr[14], recSensor.get(0),
                                    recSensor.get(1), recSensor.get(2),recSensor.get(3),recSound.get(0),recSensor.get(4),recSensor.get(5),recSensor.get(6),recSensor.get(7), recSound.get(1),packNames,timeUse);

                        }


                    }
                    count++;

                }//set error checking

            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }

        }

        return sr;
    }

}
