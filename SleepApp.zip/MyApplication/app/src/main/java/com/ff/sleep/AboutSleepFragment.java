package com.ff.sleep;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class AboutSleepFragment extends Fragment implements View.OnClickListener{

    String[] urls = {"https://www.medicalnewstoday.com/articles/325353", "https://www.health.harvard.edu/press_releases/importance_of_sleep_and_health", "https://www.healthline.com/nutrition/ways-to-fall-asleep"};
    CardView a1, a2, a3;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_about_sleep, container, false);
        a1 = view.findViewById(R.id.article1);
        a2 = view.findViewById(R.id.article2);
        a3 = view.findViewById(R.id.article3);

        a1.setOnClickListener(this);
        a2.setOnClickListener(this);
        a3.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {

        Intent i;
        switch (v.getId()) {
            case R.id.article1:
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(urls[0]));
                startActivity(i);
                break;

            case R.id.article2:
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(urls[1]));
                startActivity(i);
                break;
            case R.id.article3:
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(urls[2]));
                startActivity(i);
                break;

            default:
                break;


        }

    }
}
