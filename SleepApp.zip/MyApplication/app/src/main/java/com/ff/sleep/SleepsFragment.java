package com.ff.sleep;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SleepsFragment extends Fragment {
    Button b1, b2;
    TextView welcome;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sleep, container, false);
        b1 = view.findViewById(R.id.start);
        b2 = view.findViewById(R.id.mysleeps);
        welcome = view.findViewById(R.id.welcome);

        welcome.setText("Welcome " + new Profile().returnUser().get(0)+ "! Know more about your sleep here.");


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),inBackground.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),MySleeps.class);
                startActivity(i);
            }
        });

        return view;
    }
}
