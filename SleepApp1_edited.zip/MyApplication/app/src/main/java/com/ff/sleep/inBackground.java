package com.ff.sleep;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.Toast;


import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.LineData;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class inBackground extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "inBackground";
    private String SleepID;
    private String date;
    private String time;
    private String score;

    private Chronometer chronometer;
    Boolean running;
    long pauseOffset;
    Button b1, b2, b3, b4;
    RecyclerView recyclerView;
    private LineChart lineChart1, lineChart2, lineChart3, lineChart4, lineChart6,lineChart5;

    List<String> alerts = new ArrayList<>();
    List<String> ts = new ArrayList<>();
    alertAdapter nots;

    public static sensorRecording sr;
    public static audioRecording ar;
    public static String hh, mm, ss;
    public static List<List<Float>> g1, a1, g2, a2;
    public static List<Float> l1, m1, sc1;
    public static List<Float> l2, m2;
    public static List<Double> s1;
    public static List<Double> s2;
    public static List<Float> av1, gv1, av2, gv2;

    private SensorManager sensorManager;
    private TriggerEventListener triggerEventListener;
    Sensor lightSensor;
    Sensor motionDetect;
    Sensor gyroSense;
    Sensor proximity;
    Sensor accelerometer;
    Sensor step_count;

    String target;
    ImageView target_pic;
    float stepCountTaken = 0;
    AlarmManager am;
    PendingIntent pendingIntentB;
    PowerManager.WakeLock mWakeLock;
    Vibrator vibrator;

    //app usage tracking;
    private UsageStatsManager mUsageStatsManager;
    private boolean StopRec = false;
    private List<String> mpackageName, museTime;
    private HashMap<String, Long> startPackages;
    public final static String SHARED_PREFS = "sharedPrefs";
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_background);
        chronometer = findViewById(R.id.chrono1);
        b1 = findViewById(R.id.pause);
        b2 = findViewById(R.id.stop);
        b3 = findViewById(R.id.delete);
        b4 = findViewById(R.id.analyse);
        b4.setEnabled(false);
        recyclerView = findViewById(R.id.recview1);
        target_pic = findViewById(R.id.target_reached);
        target_pic.setImageDrawable(null);
        lineChart1 = findViewById(R.id.chart1);
        lineChart3 = findViewById(R.id.chart3);
        lineChart4 = findViewById(R.id.chart4);
        lineChart5 = findViewById(R.id.chart5);
        lineChart6 = findViewById(R.id.chart6);

        alerts = new ArrayList<>();
        ts = new ArrayList<>();

        Toast.makeText(inBackground.this,"Do not shut your phone during the first 30 seconds to allow for configurations", Toast.LENGTH_LONG).show();

        setDateandTime();
        mUsageStatsManager = (UsageStatsManager) getApplicationContext().getSystemService(Context.USAGE_STATS_SERVICE);



        nots = new alertAdapter(inBackground.this, alerts, ts);
        recyclerView.setAdapter(nots);
        recyclerView.setLayoutManager(new LinearLayoutManager(inBackground.this));
        List<String> profData = null;
        try {
            profData = getProfile();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if(profData != null && profData.get(profData.size()-1).equals("True")){
            vibrator = (Vibrator) getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
        }
        if(profData != null){
            String targetProf = profData.get(8);
            target = String.valueOf((Integer.parseInt(targetProf) * 60) + (Float.parseFloat(targetProf)- Integer.parseInt(targetProf)*60));

        }


        //sensor data plotting

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        gyroSense = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        motionDetect = sensorManager.getDefaultSensor(Sensor.TYPE_SIGNIFICANT_MOTION);
        step_count = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        proximity = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        List<Sensor> sensors = sensorManager.getSensorList(Sensor.TYPE_ALL);

        for(int i=0; i<sensors.size(); i++){
            Log.d(TAG, "onCreate: Sensor "+ i + ": " + sensors.get(i).toString());
        }






        sr = new sensorRecording(inBackground.this, lightSensor,motionDetect,gyroSense,accelerometer,step_count, proximity, sensorManager);
        try {
            ar = new audioRecording(inBackground.this);
            ar.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //sensorData collections initialised

        g1 = new ArrayList<>();
        a1 = new ArrayList<>();
        g2 = new ArrayList<>();
        a2 = new ArrayList<>();
        l1 = new ArrayList<>();
        m1 = new ArrayList<>();
        sc1 = new ArrayList<>();
        l2 = new ArrayList<>();
        m2 = new ArrayList<>();
        s1 = new ArrayList<>();
        s2 = new ArrayList<>();
        av1 = new ArrayList<>();
        gv1 = new ArrayList<>();
        av2 = new ArrayList<>();
        gv2 = new ArrayList<>();

        //sensorData charts
        LineChart[] chartsColl = {lineChart1,lineChart3, lineChart4, lineChart5,lineChart6};
        for(LineChart chart: chartsColl){
            chart.getDescription().setEnabled(true);
            chart.getDescription().setText("Real-time data");
            chart.getDescription().setTextColor(Color.WHITE);
            chart.setTouchEnabled(true);
            chart.setDragEnabled(false);
            chart.setScaleEnabled(true);
            chart.setDrawGridBackground(false);
            chart.setPinchZoom(true);
            chart.setBackgroundColor(Color.rgb(56,56,56));

            LineData lineData = new LineData();
            lineData.setValueTextColor(Color.WHITE);
            lineData.setValueTextSize(10f);
            chart.setData(lineData);

            XAxis xl = chart.getXAxis();
            xl.setAxisLineColor(Color.WHITE);
            xl.setTextColor(Color.WHITE);
            xl.setEnabled(true);
            xl.setDrawLabels(false);
            xl.setAvoidFirstLastClipping(true);
            xl.setPosition(XAxis.XAxisPosition.BOTTOM_INSIDE);

            YAxis leftAxis = chart.getAxisLeft();
            leftAxis.setAxisLineColor(Color.WHITE);
            leftAxis.setTextColor(Color.WHITE);
            leftAxis.setAxisMinimum(0f);
            leftAxis.setGranularity(1f);

            YAxis rightAxis = chart.getAxisRight();
            rightAxis.setEnabled(false);

            chart.invalidate();
        }

        /**IntentFilter screenStateFilter = new IntentFilter();
        screenStateFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenStateFilter.addAction(Intent.ACTION_SCREEN_OFF);
        screenStateFilter.addAction(Intent.ACTION_BOOT_COMPLETED);
        registerReceiver(new inBackgroundReceiver(),screenStateFilter);**/

        startChrono();
        sr.startPlot(lineChart4, lineChart1,lineChart6,lineChart3,null);
        ar.startPlot(lineChart5);

        triggerEventListener = new TriggerEventListener() {
            @Override
            public void onTrigger(TriggerEvent event) {

                if(alerts.contains("Significant motion detected")){
                    int reqIndex = alerts.indexOf("Significant motion detected");
                    alerts.remove(reqIndex);
                    ts.remove(reqIndex);

                }

                alerts.add("Significant motion detected");
                ts.add(chronometer.getText().toString());
                nots.updateList(alerts, ts);
                nots.notifyDataSetChanged();
                if(vibrator != null){
                    vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
                }


            }
        };

        chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener(){
            @Override
            public void onChronometerTick(Chronometer cArg) {
                long time = SystemClock.elapsedRealtime() - cArg.getBase();
                int h   = (int)(time /3600000);
                int m = (int)(time - h*3600000)/60000;
                int s= (int)(time - h*3600000- m*60000)/1000 ;
                hh = h < 10 ? "0"+h: h+"";
                mm = m < 10 ? "0"+m: m+"";
                ss = s < 10 ? "0"+s: s+"";
                cArg.setText(hh+":"+mm+":"+ss);

                checkAlerts();



                if(sr.getSt1().size() > 0){

                    if(sr.getSt1().get(sr.getSt1().size()-1) > stepCountTaken){
                        if(alerts.contains("Step detected" + " (" + stepCountTaken + " steps)" )){
                            int reqIndex = alerts.indexOf("Step detected" + " (" + stepCountTaken + " steps)");
                            alerts.remove(reqIndex);
                            ts.remove(reqIndex);

                        }
                        stepCountTaken = sr.getSt1().get(sr.getSt1().size()-1);

                        alerts.add("Step detected" + " (" + stepCountTaken + " steps)");
                        ts.add(chronometer.getText().toString());
                        nots.updateList(alerts, ts);
                        nots.notifyDataSetChanged();
                        if(vibrator != null){
                            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
                        }

                    } else {


                    }

                }


                if("12:00:00".equals(cArg.getText())){
                    alerts.add("No more data can be recorded after 12 hour recordings");
                    ts.add(cArg.getText().toString());
                    nots.updateList(alerts,ts);
                    nots.notifyDataSetChanged();
                    ar.stopMicrophone();
                    sr.Pause();
                    StopRec = true;
                }
                if(target != null){
                    if(target.equals(String.valueOf(Integer.valueOf(hh)*60 + Integer.parseInt(mm)))){
                        cArg.setTextColor(Color.GREEN);
                        target_pic.setImageResource(R.drawable.target);
                    }
                }

                final Calendar cal = Calendar.getInstance();
                cal.add(Calendar.YEAR, -1);

                List<UsageStats> queryUsageStats = mUsageStatsManager
                        .queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.getTimeInMillis(),
                                System.currentTimeMillis());
                for (int i = 0; i < queryUsageStats.size(); i ++){
                    if(!queryUsageStats.get(i).getPackageName().equals(getPackageName())){
                        if(alerts.contains(queryUsageStats.get(i).getPackageName() + " was used")){
                            int reqIndex = alerts.indexOf(queryUsageStats.get(i).getPackageName() + " was used");
                            alerts.remove(reqIndex);
                            ts.remove(reqIndex);


                        }
                        alerts.add(queryUsageStats.get(i).getPackageName() + " was used");
                        long last_time = queryUsageStats.get(i).getLastTimeStamp();
                        ts.add(String.valueOf(last_time));

                    }
                }
                String cTime = cArg.getText().toString();

                if(StopRec == false && cTime.equals("00:00:02")){

                    List<Double> initSound = new ArrayList<>();
                    List<Double> initSoundV = new ArrayList<>();
                    double amplitude = ar.calcAmplitude();

                    if(initSound.size() > 0){
                        initSoundV.add(amplitude/initSound.get(initSound.size()-1));
                    }
                    else{
                        initSoundV.add(1.00);
                    }
                    initSound.add(amplitude);
                    createAveragesV(sr.getL1(),sr.getM1(),sr.getG1(),sr.getA1(), initSoundV);
                    createAverages(sr.getL2(),sr.getM2(),sr.getG2(),sr.getA2(), sr.getSt1(),initSound);


                }
                if(StopRec == false && cTime.substring(cTime.indexOf(":")+1, cTime.length()).equals("30:00")){


                    createAveragesV(sr.getL1(),sr.getM1(),sr.getG1(),sr.getA1(), ar.getAmplitudesV());
                    createAverages(sr.getL2(),sr.getM2(),sr.getG2(),sr.getA2(), sr.getSt1(),ar.getAmplitudes());


                }

                if(StopRec == false){
                    lineChart4 = sr.getC1();
                    lineChart1 = sr.getC2();
                    lineChart6 = sr.getC3();
                    lineChart3 = sr.getC4();
                    lineChart5 = ar.getC1();
                }
                if(StopRec == false){
                    if(am!= null && pendingIntentB != null){
                        am.cancel(pendingIntentB);
                    }

                }
            }
        });

    }
    public void startChrono(){
        //acquireWakeLock();
        pauseOffset = 0;
        chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
        chronometer.start();
        running = true;
        am = (AlarmManager)getSystemService(ALARM_SERVICE);
        /**Intent ib = new Intent(this, inBackgroundReceiver.class);
        pendingIntentB = PendingIntent.getBroadcast(
                inBackground.this, 0, ib, PendingIntent.FLAG_UPDATE_CURRENT);

        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(System.currentTimeMillis());

        //int interval = 180000;
        int interval = 1000;
        am.setRepeating(AlarmManager.RTC, t.getTimeInMillis(), interval, pendingIntentB);**/
    }
    public void stopChrono(View view) throws IOException {
        if(mm.equals("00") && hh.equals("00")){
            Toast.makeText(inBackground.this, "Too short a recording",Toast.LENGTH_LONG).show();
        }
        else{
            chronometer.stop();
            try {
                saveSleepData();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            b1.setText("Start New Sleep");
            b4.setEnabled(true);
            sr.Pause();
            ar.stopMicrophone();
        }

    }

    public void pauseChrono(View view) {
        if(b1.getText().toString().equals("Start New Sleep")){
            startActivity(new Intent(inBackground.this,MainActivity.class).putExtra("Restart", "Y"));

        }
        else{
            if(running){
                chronometer.stop();
                pauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
                b1.setText("Resume Sleep Recording");
                running = false;
                sr.Pause();
                ar.pauseMicrophone();
            }
            else{
                //CHECK THIS
                chronometer.setBase(SystemClock.elapsedRealtime() - pauseOffset);
                chronometer.start();
                running = true;
                sr.Resume();
                b1.setText("Pause Sleep Recording");
                ar.resumeMicrophone();
                sr.startPlot(lineChart1,lineChart2,lineChart3,lineChart4,lineChart6);
                ar.startPlot(lineChart5);
            }
        }



    }

    public void delete(View view) {
        chronometer.stop();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to delete? All data will be deleted.")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        sr.Pause();
                        ar.stopMicrophone();
                        startActivity(new Intent(inBackground.this,MainActivity.class));
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();



    }

    @Override
    public void onBackPressed() {
        if(!b4.isEnabled()){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Are you sure you want to delete? All data will be deleted.")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            sr.getThread().interrupt();
                            ar.getThread().interrupt();
                            finish();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

    }

    public static void createAverages(List<Float> lData, List<Float> mData, List<List<Float>> gData, List<List<Float>> aData, List<Float> scData, List<Double> sData){

        //averages
        if(lData != null){
            l2.add(calcAvgS(lData));
            Log.d(TAG,String.valueOf(l2.get(0)));
        }
        if(mData != null){
            m2.add(calcAvgS(mData));
        }
        if(gData != null && gData.size() != 0){
            g2.add(0,new ArrayList<Float>());
            g2.add(1,new ArrayList<Float>());
            g2.add(2,new ArrayList<Float>());
            g2.get(0).add(calcAvgS(gData.get(0)));
            g2.get(1).add(calcAvgS(gData.get(1)));
            g2.get(2).add(calcAvgS(gData.get(2)));

            gv2.add(calcAvgRotVector(calcAvgS(gData.get(0)),calcAvgS(gData.get(1)),calcAvgS(gData.get(2))));
        }
        if(aData != null && aData.size() != 0){
            a2.add(0,new ArrayList<Float>());
            a2.add(1,new ArrayList<Float>());
            a2.add(2,new ArrayList<Float>());
            a2.get(0).add(calcAvgS(aData.get(0)));
            a2.get(1).add(calcAvgS(aData.get(1)));
            a2.get(2).add(calcAvgS(aData.get(2)));
            av2.add(calcAvgAccVector(calcAvgS(aData.get(0)),calcAvgS(aData.get(1)),calcAvgS(aData.get(2))));


        }
        if(scData != null){
            sc1.add(calcAvgS(scData));

        }

        if(sData != null){
            s2.add(calcAvgSound(sData));

        }

        sr.clear();
        sr.restart();
        ar.clear();
        ar.restart();

    }
    public static float calcAvgS(List<Float> data){
        float favg = 0f;
        for (Float f: data){

            favg += f;

        }

        favg = (favg/data.size());

        return favg;
    }

    public static double calcAvgSound(List<Double> data){
        double favg = 0f;
        for (double f: data){

            favg += f;

        }

        favg = (favg/data.size());

        return favg;
    }

    public static void createAveragesV(List<Float> lData, List<Float> mData, List<List<Float>> gData, List<List<Float>> aData, List<Double> sData){

        //averages
        if(lData != null){
            l1.add(calcAvgS(lData));
        }
        if(mData != null){
            m1.add(calcAvgS(mData));
        }
        if(gData != null && gData.size() != 0){
            g1.add(0,new ArrayList<Float>());
            g1.add(1,new ArrayList<Float>());
            g1.add(2,new ArrayList<Float>());
            g1.get(0).add(calcAvgS(gData.get(0)));
            g1.get(1).add(calcAvgS(gData.get(1)));
            g1.get(2).add(calcAvgS(gData.get(2)));
            gv1.add(calcAvgRotVector(calcAvgS(gData.get(0)),calcAvgS(gData.get(1)),calcAvgS(gData.get(2))));
        }
        if(aData != null && aData.size() != 0){
            a1.add(0,new ArrayList<Float>());
            a1.add(1,new ArrayList<Float>());
            a1.add(2,new ArrayList<Float>());
            a1.get(0).add(calcAvgS(aData.get(0)));
            a1.get(1).add(calcAvgS(aData.get(1)));
            a1.get(2).add(calcAvgS(aData.get(2)));
            av1.add(calcAvgAccVector(calcAvgS(aData.get(0)),calcAvgS(aData.get(1)),calcAvgS(aData.get(2))));
        }
        if(sData != null){
            s1.add(calcAvgSound(sData));
        }

        sr.clearV();
        sr.restartV();
        ar.clearV();
        ar.restartV();

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void saveSleepData() throws IOException, ParseException {
        genSleepID();
        new WriteCSV("User", null, inBackground.this, null).changeUserData(SleepID);

        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date dateobj = new Date();

        String[] tokens = df.format(dateobj).split("\\s+");

        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -1);

        List<UsageStats> queryUsageStats = mUsageStatsManager
                .queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.getTimeInMillis(),
                        System.currentTimeMillis());

        for (int i = 0; i < queryUsageStats.size(); i ++){
            if(!queryUsageStats.get(i).getPackageName().equals(getPackageName())){
                mpackageName.add(queryUsageStats.get(i).getPackageName());
                long duration = queryUsageStats.get(i).getTotalTimeInForeground();
                if(startPackages.containsKey(queryUsageStats.get(i).getPackageName())){
                    long begTime = startPackages.get(queryUsageStats.get(i).getPackageName());
                    museTime.add(String.valueOf(duration-begTime));
                }
                else{
                    museTime.add(String.valueOf(duration));
                }


            }
        }

        float timeDurH = Integer.parseInt(hh)*60;
        float timeDurM = Integer.parseInt(mm);

        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        Date date1 = format.parse(time);
        Date date2 = format.parse(tokens[1]);
        long difference = date2.getTime() - date1.getTime();
        long diffMinutes = difference / (60 * 1000) % 60;

        score = "6 6 6 6";

        SleepRecording sleepData = new SleepRecording(SleepID, date, (time + " to " + tokens[1]), score, String.valueOf(diffMinutes), String.valueOf(calcAvgS(av2)), String.valueOf(calcAvgS(m2)), String.valueOf(calcAvgS(gv2)), String.valueOf(calcAvgS(l2)),
                String.valueOf(calcAvgSound(s2)), String.valueOf(calcAvgS(av1)), String.valueOf(calcAvgS(m1)), String.valueOf(calcAvgS(gv1)), String.valueOf(calcAvgS(l1)),
                String.valueOf(calcAvgSound(s1)), av2,m2,gv2,l2,s2,av1,m1,gv1,l1,s1,mpackageName, museTime);
        for(int i = 0; i < av2.size();i++){
            Log.d(TAG, String.valueOf(av2.get((i))));
        }


        ArrayList mdata = new ArrayList();
        mdata.add(sleepData);

        //make the data list;
        try {
            new WriteCSV("My Sleeps", SleepID, inBackground.this, mdata).addSleepRecording(sleepData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void genSleepID() throws FileNotFoundException {
        Random rand = new Random();

        boolean match = false;

        List<List<String>> sleeps = new readCSV(inBackground.this, "My Sleeps").readRecord();
        int count = 0;
        while (match == true || (match == false && count == 0)){
            match = false;
            int testID = rand.nextInt(100000000);

            Log.d(TAG, "Finding a match" + " " + String.valueOf(testID));


            for(List<String> l1: sleeps){
                Log.d(TAG, "Finding a match" + " " + String.valueOf(testID));
                for (String id: l1){
                    if (id.equals(String.valueOf(testID))){

                        match = true;
                        SleepID = "";
                    }

                }
            }

            if(match == false){

                SleepID = String.valueOf(testID);

            }
            Log.d(TAG, "Finding a match" + " " + String.valueOf(testID));
            count++;

        }



    }



    public void setDateandTime(){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dateobj = new Date();

        String[] tokens = df.format(dateobj).split("\\s+");

        if(tokens.length >= 2){
            date = tokens[0];
            time = tokens[1];
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if(b1.getText().toString().equals("Pause Sleep Recording")) {
            sensorManager.registerListener((SensorEventListener) sr.getContext(), accelerometer, sensorRecording.DELAY);
            sensorManager.registerListener((SensorEventListener) sr.getContext(),lightSensor,sensorRecording.DELAY);
            sensorManager.registerListener((SensorEventListener) sr.getContext(),gyroSense,sensorRecording.DELAY);
            sensorManager.registerListener((SensorEventListener) sr.getContext(),step_count,sensorRecording.DELAY);
            sensorManager.registerListener((SensorEventListener) sr.getContext(),proximity,sensorRecording.DELAY);
        }
        //acquireWakeLock();
    }

    @Override
    protected void onDestroy() {
        sensorManager.unregisterListener(this);
        ar.stopMicrophone();
        super.onDestroy();

    }

    @Override
    protected void onPause() {
        super.onPause();

        if (sr.getThread() != null) {
            sr.getThread().interrupt();
        }
        if (ar.getThread() != null) {
            ar.getThread().interrupt();
        }
        sensorManager.unregisterListener(this);
        // releaseWakeLock() ;

    }

    @Override
    public void onSensorChanged(SensorEvent event) {


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void checkAlerts(){

        /**if(Results.thresholds != null && Results.thresholdsV != null){

         for (int i = 0; i < Results.thresholds.length; i++) {

         if (Results.thresholds[2] > sr.getM2().get(sr.getM2().size() - 1) || Results.thresholds[3] < sr.getM2().get(sr.getM2().size() - 1)) {
         if(alerts.contains("Extreme motion level detected")){
         int reqIndex = alerts.indexOf("Extreme motion level detected");
         alerts.remove(reqIndex);
         ts.remove(reqIndex);

         }
         alerts.add("Extreme motion level detected");
         ts.add(chronometer.getText().toString());
         nots.updateList(alerts, ts);
         nots.notifyDataSetChanged();
         }



         if (Results.thresholds[6] > sr.getL2().get(sr.getL2().size() - 1) || Results.thresholds[7] < sr.getL2().get(sr.getL2().size() - 1)) {
         if(alerts.contains("Extreme light level detected")){
         int reqIndex = alerts.indexOf("Extreme light level detected");
         alerts.remove(reqIndex);
         ts.remove(reqIndex);

         }

         alerts.add("Extreme light level detected");
         ts.add(chronometer.getText().toString());
         nots.updateList(alerts, ts);
         nots.notifyDataSetChanged();
         }

         if (Results.thresholds[8] > s2.get(s2.size() - 1) || Results.thresholds[9] < s2.get(s2.size() - 1)) {
         if(alerts.contains("Extreme sound level detected")){
         int reqIndex = alerts.indexOf("Extreme sound level detected");
         alerts.remove(reqIndex);
         ts.remove(reqIndex);

         }
         alerts.add("Extreme sound level detected");
         ts.add(chronometer.getText().toString());
         nots.updateList(alerts, ts);
         nots.notifyDataSetChanged();
         }

         if (Results.thresholdsV[2] > sr.getM1().get(sr.getM1().size() - 1) || Results.thresholdsV[3] < sr.getM1().get(sr.getM1().size() - 1)) {
         if(alerts.contains("Extreme motion change detected")){
         int reqIndex = alerts.indexOf("Sound rotation level detected");
         alerts.remove(reqIndex);
         ts.remove(reqIndex);

         }

         alerts.add("Extreme motion change detected");
         ts.add(chronometer.getText().toString());
         nots.updateList(alerts, ts);
         nots.notifyDataSetChanged();
         }
         if (Results.thresholdsV[6] > sr.getL1().get(sr.getL1().size() - 1) || Results.thresholdsV[7] < sr.getL1().get(sr.getL1().size() - 1)) {
         if(alerts.contains("Extreme light level change detected")){
         int reqIndex = alerts.indexOf("Extreme light level change detected");
         alerts.remove(reqIndex);
         ts.remove(reqIndex);

         }


         alerts.add("Extreme light level change detected");
         ts.add(chronometer.getText().toString());
         nots.updateList(alerts, ts);
         nots.notifyDataSetChanged();
         }
         if (Results.thresholdsV[8] > s1.get(s1.size() - 1) || Results.thresholdsV[9] < s1.get(s1.size() - 1)) {
         if(alerts.contains("Extreme sound level change detected")){
         int reqIndex = alerts.indexOf("Extreme sound level change detected");
         alerts.remove(reqIndex);
         ts.remove(reqIndex);

         }
         alerts.add("Extreme sound level change detected");
         ts.add(chronometer.getText().toString());
         nots.updateList(alerts, ts);
         nots.notifyDataSetChanged();
         }
         }
         }**/


    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void analyse(View view) throws IOException {

        Intent i = new Intent(inBackground.this,Results.class);
        i.putExtra("Sleep ID", SleepID);
        startActivity(i);
    }

    private static float calcAvgRotVector(float X, float Y, float Z){

        double mag = Math.sqrt((X*X) + (Y*Y) + (Z*Z));

        return (float) mag;

    }
    private static float calcAvgAccVector(float X, float Y, float Z){
        double mag = Math.sqrt((X*X) + (Y*Y) + (Z*Z));

        return (float) mag;

    }

    public void saveTimeData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("TimeStamp",chronometer.getText().toString());
    }

    public void loadTimeData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        chronometer.setText(sharedPreferences.getString("TimeStamp",""));
    }

    public  class inBackgroundReceiver extends BroadcastReceiver{
        private String input = "Audio Recording";

        @Override
        public void onReceive(Context context, Intent intent) {

            Log.w(TAG,"inBackgroundReceiver");

            Context oAppContext = context.getApplicationContext();

            if (oAppContext == null) {
                oAppContext = context;
            }


            Intent serviceIntent2 = new Intent(oAppContext, inBackgroundService.class);
            serviceIntent2.putExtra("inputExtra",input);
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                oAppContext.startForegroundService(serviceIntent2);
            }
            else{
                oAppContext.startService(serviceIntent2);
            }




        }
    }

    public void acquireWakeLock() {
        final PowerManager powerManager = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        // releaseWakeLock();
        //Acquire new wake lock
        mWakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PARTIAL_WAKE_LOCK:");
        mWakeLock.acquire();
    }

    public void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            mWakeLock = null;
        }
    }

    public List<String> getProfile() throws FileNotFoundException {
        List<String> currUser = new readCSV(inBackground.this,"User").userProfiles();

        List<String> mProfile = null;
        if(currUser != null && currUser.size() >= 3){
            mProfile = new readCSV(inBackground.this,"Profile").readProfiles(currUser.get(0),currUser.get(2));

        }

        return mProfile;
    }



}
