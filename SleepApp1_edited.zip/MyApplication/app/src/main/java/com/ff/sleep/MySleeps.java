package com.ff.sleep;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ff.sleep.R;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MySleeps extends AppCompatActivity {

    private static String TAG = "MySleeps";

    RecyclerView recyclerView;
    TextView noSleeps;
    String[] TT, DT, ID;
    List<List<String>> mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sleeps);
        recyclerView = findViewById(R.id.recview1);
        noSleeps = findViewById(R.id.noSleeps);

        noSleeps.setVisibility(View.GONE);

        try {
            getSleepsData(Profile.USER_EMAIL_PHONE);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }

    private void getSleepsData(String email_phone) throws FileNotFoundException {
        mData = new ArrayList<>();
        List<String> user = new readCSV(MySleeps.this, "User").userProfiles();
        if (user != null){
            Log.d(TAG,user.get(1));
        }

        if(user != null){
            if(user.size() == 4){
                Log.d(TAG,user.get(3));
                if(user.get(3) != "" && user.get(3) != null){
                    ID = user.get(3).split("\\s+");
                    ID = reverseArray(ID);
                    TT = new String[ID.length];
                    DT = new String[ID.length];
                    for (int i = 0; i < ID.length; i++){
                        SleepRecording mSR = new readCSV(MySleeps.this, "My Sleeps").readSingleRecord(ID[i]);
                        if(mSR != null){
                            TT[i] = mSR.getmSleepTimes();
                            DT[i] = mSR.getmSleepDate();
                        }

                    }

                    if(TT.length == 1){
                        ID = new String[]{" "};
                        TT = new String[0];
                        DT = new String[0];
                        recyclerView.setVisibility(View.GONE);
                        Toast.makeText(MySleeps.this, "No sleeps recorded yet", Toast.LENGTH_LONG).show();
                        noSleeps.setVisibility(View.VISIBLE);
                    }
                    else{
                        mySleepsAdapter sleepsAdapter = new mySleepsAdapter(MySleeps.this, TT, DT, ID);
                        recyclerView.setAdapter(sleepsAdapter);
                        recyclerView.setLayoutManager(new LinearLayoutManager(MySleeps.this));

                    }


                }
                else{
                    ID = new String[]{" "};
                    TT = new String[0];
                    DT = new String[0];
                    recyclerView.setVisibility(View.GONE);
                    Toast.makeText(MySleeps.this, "No sleeps recorded yet", Toast.LENGTH_LONG).show();
                    noSleeps.setVisibility(View.VISIBLE);
                }

            }

            else{
                ID = new String[]{" "};
                TT = new String[0];
                DT = new String[0];
                recyclerView.setVisibility(View.GONE);
                Toast.makeText(MySleeps.this, "No sleeps recorded yet", Toast.LENGTH_LONG).show();
                noSleeps.setVisibility(View.VISIBLE);
            }

        }
        else{
            ID = new String[]{" "};
            TT = new String[0];
            DT = new String[0];
            recyclerView.setVisibility(View.GONE);
            Toast.makeText(MySleeps.this, "No sleeps recorded yet", Toast.LENGTH_LONG).show();
            noSleeps.setVisibility(View.VISIBLE);
        }





    }


    public String[] reverseArray(String[] arr) {
        // Converting Array to List
        List<String> list = Arrays.asList(arr);
        // Reversing the list using Collections.reverse() method
        Collections.reverse(list);
        // Converting list back to Array
        String[] reversedArray = list.toArray(arr);

        return reversedArray;
    }
}
