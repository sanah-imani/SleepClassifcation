package com.ff.sleep;

import android.app.Activity;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

public class NotificationCreator {

    private static final int NOTIFICATION_ID = 1094;
    private static final String CHANNEL_ID = "Foreground Service Channel";
    private static Notification notification;

    public static Notification getNotification(Context context) {

        if(notification == null) {

            Intent notificationIntent = new Intent(context, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(context,
                    0, notificationIntent, 0);

            notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setContentTitle("Try Foreground Service")
                    .setContentText("Recording occuring")
                    .setContentIntent(pendingIntent)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .build();
        }

        return notification;
    }

    public static int getNotificationId() {
        return NOTIFICATION_ID;
    }
}
