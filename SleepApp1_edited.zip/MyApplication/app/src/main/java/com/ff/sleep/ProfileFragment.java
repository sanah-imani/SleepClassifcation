package com.ff.sleep;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.charts.Pie;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.data.PieData;
import com.google.android.material.textfield.TextInputEditText;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {

    String[] sleep_qual = {"Poor", "Average", "Good", "Excellent"};
    String[] sleep_time_pie = {"Met sleep time goal", "Less than sleep goal time"};
    double[] perc_qual;
    double[] perc_time;
    private List<String> profile_tokens;
    public static String USER_NAME;
    public static String USER_EMAIL_PHONE;
    public static String SLEEP_TARGET;
    public String[] SleepIDs;


    List<List<String>> mData;

    PieChart chart1, chart2;
    BarChart barChart1, barChart2, barChart3, barChart4;
    float[] sleep_time_bar, light_bar, motion_bar, sound_bar;
    String[] day_bar;
    CheckBox check1, check2;
    Button edit, sync;
    Boolean editing = false;
    TextInputEditText age, sleep_time, weight, height;
    TextView device_name;
    TextView username;
    CircleImageView profile_pic;
    RadioButton rb1, rb2;
    CheckBox vib;

    float[] thresholdScores = {0.00f, 10.00f, 0.00f, 10.00f, 0.00f, 10.00f};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_profile, container, false);

        chart1 = view.findViewById(R.id.sleep_qual);
        chart2 = view.findViewById(R.id.sleep_time_pie);
        barChart1 = view.findViewById(R.id.sleep_time_bar);
        barChart2 = view.findViewById(R.id.light_var_bar);
        barChart3 = view.findViewById(R.id.motion_var_bar);
        barChart4 = view.findViewById(R.id.sound_var_bar);
        check1 = view.findViewById(R.id.check1);
        check2 = view.findViewById(R.id.checKSleepRecs);
        edit = view.findViewById(R.id.editprofile);
        username = view.findViewById(R.id.username);
        age = view.findViewById(R.id.age);
        sleep_time = view.findViewById(R.id.sleep_time);
        weight = view.findViewById(R.id.weight);
        height = view.findViewById(R.id.height);
        profile_pic = view.findViewById(R.id.badgePic);
        rb1 = view.findViewById(R.id.metric);
        rb2 = view.findViewById(R.id.imperial);
        device_name = view.findViewById(R.id.sync);
        vib = view.findViewById(R.id.check1);
        try {
            getUser();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            getData();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            fillProfile();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        profile_pic.setEnabled(false);
        rb1.setEnabled(false);
        rb2.setEnabled(false);
        age.setEnabled(false);
        sleep_time.setEnabled(false);
        weight.setEnabled(false);
        height.setEnabled(false);
        vib.setEnabled(false);
        check1.setEnabled(false);
        check2.setEnabled(false);


        if(mData != null || mData.size() == 0){
            chart1.setVisibility(View.VISIBLE);
            chart2.setVisibility(View.VISIBLE);
            barChart1.setVisibility(View.VISIBLE);
            barChart2.setVisibility(View.VISIBLE);
            barChart3.setVisibility(View.VISIBLE);
            barChart4.setVisibility(View.VISIBLE);

            getSleepScorePerc(3);
            getSleepTimeFulfilled(4);

            PieData data1 = new myTrends(getActivity()).setUpPieMPChart(sleep_qual, perc_qual,"Sleep Quality Percentages");
            if (data1 == null){
                Toast.makeText(getActivity(), "No sleep quality pie chart could be generated", Toast.LENGTH_SHORT).show();
            }
            else{
                data1.setValueTextSize(13f);
                data1.setValueTextColor(Color.WHITE);
                chart1.clear();
                chart1.getLegend().setTextColor(Color.WHITE);
                chart1.getDescription().setText("");
                LegendEntry[] legendEntries = chart1.getLegend().getEntries();
                for(int j = 0; j < legendEntries.length; j++){
                    Log.w("ProfFrag", legendEntries[j].label);
                    if(legendEntries[j].label.equals("")){

                        legendEntries[j].label = sleep_qual[j];
                    }
                }
                chart1.getLegend().setCustom(legendEntries);
                chart1.setUsePercentValues(true);
                chart1.setDrawHoleEnabled(false);
                chart1.setData(data1);
                chart1.invalidate();

            }

            PieData data2 = new myTrends(getActivity()).setUpPieMPChart(sleep_time_pie, perc_time, "Sleep Satisfaction Percentages");
            if (data2 == null){
                Toast.makeText(getActivity(), "No sleep time goal chart could be generated", Toast.LENGTH_SHORT).show();
            }
            else{
                chart2.clear();
                data2.setValueTextSize(13f);
                data2.setValueTextColor(Color.WHITE);
                chart2.getLegend().setTextColor(Color.WHITE);
                chart2.getDescription().setText("");
                LegendEntry[] legendEntries = chart2.getLegend().getEntries();
                for(int j = 0; j < legendEntries.length; j++){
                    if(legendEntries[j].label.equals("")){
                        legendEntries[j].label = sleep_time_pie[j];
                    }
                }
                chart2.getLegend().setCustom(legendEntries);
                chart2.setUsePercentValues(true);
                chart2.setDrawHoleEnabled(false);
                chart2.setData(data2);
                chart2.invalidate();
            }

            getDataForBar(1,4,3,2,1,3);
            barChart1 = new myTrends(getActivity()).setBarChart(day_bar,sleep_time_bar, "Sleep time (mins) during this week", barChart1, "Week days");

            String[] recTimes = null;
            try {
                recTimes = new readCSV(getContext(), "Sleep Recs").getSleepRec(age.getEditableText().toString());

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            if(recTimes != null){
                setThresholdLines(calcAvg(sleep_time_bar), Float.parseFloat(recTimes[1]), Float.parseFloat(recTimes[2]),barChart1);
            }

            barChart2 = new myTrends(getActivity()).setBarChart(day_bar,light_bar, "Sleep light score during this week", barChart2, "Week days");
            setThresholdLines(calcAvg(light_bar), thresholdScores[0], thresholdScores[1],barChart2);
            barChart3 = new myTrends(getActivity()).setBarChart(day_bar,motion_bar, "Sleep motion score during this week", barChart3, "Week days");
            setThresholdLines(calcAvg(motion_bar), thresholdScores[2], thresholdScores[3],barChart3);
            barChart4 = new myTrends(getActivity()).setBarChart(day_bar, sound_bar, "Sleep sound score during this week", barChart4, "Week days");
            setThresholdLines(calcAvg(sound_bar), thresholdScores[4], thresholdScores[5],barChart4);


        }
        else{
            chart1.setVisibility(View.GONE);
            chart2.setVisibility(View.GONE);
            barChart1.setVisibility(View.GONE);
            barChart2.setVisibility(View.GONE);
            barChart3.setVisibility(View.GONE);
            barChart4.setVisibility(View.GONE);

        }


        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editing){
                    Boolean val = checkValidation();
                    if (val){
                        ArrayList<String> newProfile = new ArrayList<>();
                        newProfile.add(0, USER_NAME);
                        newProfile.add(1, USER_EMAIL_PHONE);
                        newProfile.add(2,"None");
                        newProfile.add(3, age.getText().toString());
                        newProfile.add(4, device_name.getText().toString());
                        String measSys = null;
                        if(rb1.isChecked()){
                            measSys = rb1.getText().toString();
                        }
                        else{
                            measSys = rb2.getText().toString();
                        }
                        newProfile.add(5, measSys);
                        newProfile.add(6,weight.getText().toString());
                        newProfile.add(7,height.getText().toString());
                        newProfile.add(8, sleep_time.getText().toString());
                        if(check1.isChecked()){
                            newProfile.add(9,"True");
                        }
                        else {
                            newProfile.add(9,"False");
                        }

                        try {
                            new WriteCSV("Profile", null, getContext(), newProfile).changeProfileData(USER_NAME,USER_EMAIL_PHONE);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(getActivity(), "Saved Successfully", Toast.LENGTH_LONG).show();
                        edit.setText("Edit");
                        editing = false;
                        profile_pic.setEnabled(false);
                        rb1.setEnabled(false);
                        rb2.setEnabled(false);
                        age.setEnabled(false);
                        sleep_time.setEnabled(false);
                        weight.setEnabled(false);
                        height.setEnabled(false);
                        vib.setEnabled(false);
                        check1.setEnabled(false);
                        check2.setEnabled(false);



                    }
                    else{
                        Toast.makeText(getActivity(), "Did not save", Toast.LENGTH_LONG).show();

                    }

                }
                else{
                    edit.setText("Save");
                    profile_pic.setEnabled(true);
                    rb1.setEnabled(true);
                    rb2.setEnabled(true);
                    editing = true;
                    age.setEnabled(true);
                    sleep_time.setEnabled(true);
                    weight.setEnabled(true);
                    height.setEnabled(true);
                    vib.setEnabled(true);
                    check1.setEnabled(true);
                    check2.setEnabled(true);


                }

            }
        });

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rb2.isChecked() && rb1.isChecked()){
                    rb2.setChecked(false);
                }

            }
        });

        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rb1.isChecked() && rb2.isChecked()){
                    rb1.setChecked(false);
                }

            }
        });

        return view;
    }


    public boolean checkValidation(){
        if(!TextUtils.isDigitsOnly(age.getText()) || !TextUtils.isDigitsOnly(sleep_time.getText()) || !TextUtils.isDigitsOnly(height.getText()) || !TextUtils.isDigitsOnly(weight.getText())){
            Toast.makeText(getActivity(), "Numeric values to be entered", Toast.LENGTH_LONG).show();
            return false;
        }
        else if(Integer.parseInt(age.getText().toString()) <= 0 || Integer.parseInt(sleep_time.getText().toString()) <= 0 || Integer.parseInt(height.getText().toString()) <= 0 || Integer.parseInt(weight.getText().toString()) <= 0){
            Toast.makeText(getActivity(), "Negative values are not accepted", Toast.LENGTH_LONG).show();
            return false;
        }
        else if(!rb1.isChecked() && !rb2.isChecked()){
            Toast.makeText(getActivity(), "You need to select a measuring scale", Toast.LENGTH_LONG).show();
            return false;

        }
        else{

        }

        return true;
    }

    public void getUser() throws FileNotFoundException {

        List<String> userTokens = new readCSV(getActivity(), "User").userProfiles();
        if (userTokens != null){
            USER_NAME = userTokens.get(0);
            USER_EMAIL_PHONE = userTokens.get(2);
            username.setText("Username: " + USER_NAME + " (" + USER_EMAIL_PHONE + ")");
            if(userTokens.size() >= 4){
                SleepIDs = userTokens.get(3).split("\\s+");
            }

        }
    }

    public void fillProfile() throws FileNotFoundException {
        profile_tokens = new readCSV(getActivity(), "Profile").readProfiles("Zahrah_Imani", "sanah@fourthfrontier.com");
        Log.d("Profile Fragment", "Setting up Profile");
        if(profile_tokens != null){
            if(profile_tokens.get(2).equals("None")){
                profile_pic.setImageResource(R.drawable.empty_profile);
            }
            else{
                //not clear yet
            }
            age.setText(profile_tokens.get(3));
            device_name.setText(profile_tokens.get(4));
            if(profile_tokens.get(5).equalsIgnoreCase("Imperial")){
                rb2.setChecked(true);

            }
            else if(profile_tokens.get(5).equalsIgnoreCase("Metric")){
                rb1.setChecked(true);
            }
            SLEEP_TARGET = profile_tokens.get(8);
            weight.setText(profile_tokens.get(6));
            height.setText(profile_tokens.get(7));
            sleep_time.setText(profile_tokens.get(8));
            if(profile_tokens.get(9).equals("True")) {
                check1.setChecked(true);
            }
        }

        check2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked == true){
                    if(age.getEditableText().equals("")){
                        Toast.makeText(getActivity(),"There is no age added", Toast.LENGTH_LONG).show();
                    }
                    else{
                        try {
                            String[] recTimes = new readCSV(getContext(), "Sleep Recs").getSleepRec(age.getEditableText().toString());
                            if(recTimes != null){
                                sleep_time.setText(recTimes[3]);
                            }
                            else{
                                Toast.makeText(getActivity(),"Sorry no appropriate time was found. Check your age.", Toast.LENGTH_SHORT).show();
                            }

                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }

                    }

                    sleep_time.setEnabled(false);
                }
                else{
                    sleep_time.setEnabled(true);
                }

            }
        });

    }



    public void getData() throws FileNotFoundException {
        if(SleepIDs != null){
            mData = new readCSV(getActivity(), "My Sleeps").readQueryRecord(SleepIDs);
        }

    }

    public void getSleepTimeFulfilled(int timeIndex){
        perc_time = new double[sleep_time_pie.length];
        perc_time[0] = 0;
        int count = mData.size();
        for (List<String> l1: mData){
            if(Integer.parseInt(SLEEP_TARGET)*60 < Integer.parseInt(l1.get(timeIndex))){
                perc_time[0] += 1;

            }
        }

        if (count > 0){
            perc_time[0] = (perc_time[0]/count)*100;
            perc_time[1] = 100.00-perc_time[0];

        }
    }

    public void getSleepScorePerc(int scoreIndex){
        perc_qual = new double[sleep_qual.length];

        if(mData.size() > 0){
            for (int i = 0; i < perc_qual.length;i++){
                perc_qual[i] = 0;
            }
            int count = mData.size();
            for (List<String> l1: mData){
                String[] tokens = l1.get(scoreIndex).split("\\s+");
                if(Integer.parseInt(tokens[0]) >= 8){
                    perc_qual[0] += 1;

                }
                else if(Integer.parseInt(tokens[0]) >= 6){
                    perc_qual[1] += 1;
                }
                else if(Integer.parseInt(tokens[0]) >= 4){
                    perc_qual[2] += 1;
                }
                else{
                    perc_qual[3] += 1;
                }
            }
            for(int j = 0; j <perc_qual.length;j++){
                perc_qual[j] = (perc_qual[j]/count)*100;

            }



        }

    }

    public void getDataForBar(int date, int time, int scores, int light, int motion, int sound){
        List<String> days = new ArrayList<>();
        List<Float> timeRaw = new ArrayList<>();
        List<Float> lightRaw = new ArrayList<>();
        List<Float> motionRaw = new ArrayList<>();
        List<Float> soundRaw = new ArrayList<>();
        if(mData.size() > 0){
            for (List<String> l1: mData){
                LocalDate d1 = LocalDate.parse(getCurrentDate(), DateTimeFormatter.ISO_LOCAL_DATE);
                LocalDate  d2 = LocalDate.parse(l1.get(date), DateTimeFormatter.ISO_LOCAL_DATE);
                Duration diff = Duration.between(d1.atStartOfDay(), d2.atStartOfDay());
                long diffDays = diff.toDays();

                if(diffDays <= Long.parseLong("7")){
                    String[] tokens = l1.get(scores).split("\\s+");
                    if(days.contains(l1.get(date))){
                        int reqIndex = days.indexOf(l1.get(date));
                        timeRaw.set(reqIndex,(timeRaw.get(reqIndex)+Float.parseFloat(l1.get(time)))/2);
                        lightRaw.set(reqIndex,(lightRaw.get(reqIndex)+Float.parseFloat(tokens[light]))/2);
                        motionRaw.set(reqIndex,(motionRaw.get(reqIndex)+Float.parseFloat(tokens[motion]))/2);
                        soundRaw.set(reqIndex,(soundRaw.get(reqIndex)+Float.parseFloat(tokens[sound]))/2);

                    }
                    else{
                        days.add(l1.get(date));
                        timeRaw.add(Float.parseFloat(l1.get(time)));
                        lightRaw.add(Float.parseFloat(tokens[light]));
                        motionRaw.add(Float.parseFloat(tokens[motion]));
                        soundRaw.add(Float.parseFloat(tokens[sound]));
                    }
                }

            }
        }


        day_bar = new String[days.size()];
        sleep_time_bar = new float[days.size()];
        light_bar = new float[days.size()];
        motion_bar = new float[days.size()];
        sound_bar = new float[days.size()];

        for(int j = 0; j < days.size(); j++){
            day_bar[j] = days.get(j);
            light_bar[j] = lightRaw.get(j);
            sleep_time_bar[j] = timeRaw.get(j);
            motion_bar[j] = motionRaw.get(j);
            sound_bar[j] = soundRaw.get(j);
        }

    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public String getCurrentDate(){

        String sDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        return sDate;

    }


    public void setThresholdLines(float avg, float lower, float upper, BarChart lc){

        lc.getAxisLeft().removeAllLimitLines();
        lc.getAxisRight().removeAllLimitLines();

        LimitLine ll = new LimitLine(upper, "Maximum");
        ll.setLineWidth(2f);
        ll.enableDashedLine(8f, 5f, 0f);
        ll.setTextSize(12f);
        ll.setLineColor(Color.RED);
        ll.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        ll.setTextColor(Color.GREEN);
        lc.getAxisLeft().addLimitLine(ll);

        LimitLine ll1 = new LimitLine(avg, "Average");
        ll1.setLineWidth(2f);
        ll1.enableDashedLine(8f, 5f, 0f);
        ll1.setTextSize(12f);
        ll1.setLineColor(Color.RED);
        ll1.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        ll1.setTextColor(Color.GREEN);
        lc.getAxisLeft().addLimitLine(ll1);



        LimitLine ll2 = new LimitLine(lower, "Minimum");
        ll2.setLineWidth(2f);
        ll2.enableDashedLine(8f, 5f, 0f);
        ll2.setTextSize(12f);
        ll2.setLineColor(Color.RED);
        ll2.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        ll2.setTextColor(Color.GREEN);
        lc.getAxisLeft().addLimitLine(ll2);



    }

    public float calcAvg(float[] arr){
        float avg = 0;
        for(int i = 0; i <arr.length; i++){
            avg += arr[i];
        }
        avg = avg/arr.length;
        return avg;
    }

}
