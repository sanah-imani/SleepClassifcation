package com.ff.sleep;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class audioService extends Service {
    NotificationManager manager;

    public static final String CHANNEL_ID = "exampleServiceChannel2";

    public audioService(){
        super();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        createNotificationChannel();

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NotificationCreator.getNotificationId(),
                NotificationCreator.getNotification(this));
        audioRecording.plotDataA = true;
        double amplitude = audioRecording.calcAmplitude();
        if(audioRecording.amplitudes != null){
            if(audioRecording.amplitudes.size() > 0){
                audioRecording.amplitudesV.add(amplitude/audioRecording.amplitudes.get(audioRecording.amplitudes.size()-1));
            }
            else{
                audioRecording.amplitudesV.add(1.00);
            }
            audioRecording.amplitudes.add(amplitude);
            if(audioRecording.plotDataA){
                audioRecording.addEntry(amplitude,audioRecording.c1);
                audioRecording.plotDataA = false;
            }
        }

        Log.w("sleepapp","audio service");
        stopSelf();
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(manager != null){
            manager.cancel(1);
        }

    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Example Service Channel2",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }
}
